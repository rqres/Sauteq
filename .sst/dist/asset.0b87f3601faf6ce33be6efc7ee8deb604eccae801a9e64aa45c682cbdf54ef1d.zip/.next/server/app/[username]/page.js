(() => {
var exports = {};
exports.id = 712;
exports.ids = [712];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 35927:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client.edge");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 85477:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 23292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        '[username]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11992)), "/Users/rqres/Code/recipe-ai/app/[username]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40812)), "/Users/rqres/Code/recipe-ai/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/rqres/Code/recipe-ai/app/[username]/page.tsx"];

    

    const originalPathname = "/[username]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/[username]/page","pathname":"/[username]","bundlePath":"app/[username]/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 81732:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89708, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 59943));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64092));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52990));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54390));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84102));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 81396));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99904));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58418));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22526))

/***/ }),

/***/ 58418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FollowButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57114);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76537);
/* harmony import */ var _clerk_nextjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3271);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44368);
/* __next_internal_client_entry_do_not_use__ default auto */ 





function FollowButton({ currentUserId, followeeId, followsInit }) {
    const { getToken } = (0,_clerk_nextjs__WEBPACK_IMPORTED_MODULE_5__/* .useAuth */ .aC)();
    const [follows, setFollows] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(followsInit);
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
        onClick: async ()=>{
            if (!currentUserId) {
                (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.notFound)();
            }
            const token = await getToken({
                template: "supabase"
            });
            if (!token) {
                (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.notFound)();
            }
            if (!follows) {
                (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_3__/* .addFollower */ .vs)({
                    followerId: currentUserId,
                    followeeId: followeeId,
                    token: token
                });
            } else {
                (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_3__/* .removeFollower */ .mM)({
                    followerId: currentUserId,
                    followeeId: followeeId,
                    token: token
                });
            }
            router.refresh();
            setFollows(!follows);
        },
        children: `${follows ? "Following" : "Follow"}`
    });
}


/***/ }),

/***/ 22526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ UserBio)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 54 modules
var esm = __webpack_require__(3271);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
;// CONCATENATED MODULE: ./components/ui/textarea.tsx



const Textarea = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
        className: (0,utils.cn)("flex min-h-[60px] w-full rounded-md border border-stone-200 bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-stone-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400 disabled:cursor-not-allowed disabled:opacity-50 dark:border-stone-800 dark:placeholder:text-stone-400 dark:focus-visible:ring-stone-800", className),
        ref: ref,
        ...props
    });
});
Textarea.displayName = "Textarea";


// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(44368);
;// CONCATENATED MODULE: ./components/ui/UserBio.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




function UserBio({ editable, metadata }) {
    const [editing, setEditing] = (0,react_experimental_.useState)(false);
    const [textValue, setTextValue] = (0,react_experimental_.useState)(metadata.bio);
    const { isLoaded, isSignedIn, user } = (0,esm/* useUser */.aF)();
    const handleSubmit = ()=>{
        try {
            user?.update({
                unsafeMetadata: {
                    bio: textValue
                }
            });
        } catch (error) {
            console.error(error);
        }
    };
    if (!editable || !isLoaded || !isSignedIn) {
        return /*#__PURE__*/ jsx_runtime_.jsx("p", {
            children: metadata.bio !== undefined ? String(metadata.bio) : ""
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            editing && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Textarea, {
                        value: textValue,
                        onChange: (e)=>setTextValue(e.target.value),
                        placeholder: "Tell us something about yourself...",
                        className: "resize-none"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        onClick: ()=>{
                            handleSubmit();
                            setEditing(false);
                        },
                        children: "Done"
                    })
                ]
            }),
            !editing && user.unsafeMetadata.bio !== undefined && user.unsafeMetadata.bio !== "" && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "-ml-2 rounded-md border-2 border-stone-200/0 px-2 py-4 transition-colors ease-in-out hover:border-stone-200/100 dark:border-stone-800/0 hover:dark:border-stone-800/100",
                onClick: ()=>setEditing(true),
                children: String(user.unsafeMetadata.bio)
            }),
            !editing && (user.unsafeMetadata.bio === undefined || user.unsafeMetadata.bio === "") && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                onClick: ()=>setEditing(true),
                className: "-ml-2 rounded-md border-2 border-stone-200/0 px-2 py-4 text-stone-500 transition-colors ease-in-out hover:border-stone-200/100 dark:border-stone-800/0 dark:text-stone-400 hover:dark:border-stone-800/100",
                children: "Add a bio"
            })
        ]
    });
}


/***/ }),

/***/ 81396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Label: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(43618);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11914);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12857);
/* __next_internal_client_entry_do_not_use__ Label auto */ 




const labelVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_2__/* .cva */ .j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .f, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)(labelVariants(), className),
        ...props
    }));
Label.displayName = _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .f.displayName;



/***/ }),

/***/ 99904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sheet: () => (/* binding */ Sheet),
/* harmony export */   SheetClose: () => (/* binding */ SheetClose),
/* harmony export */   SheetContent: () => (/* binding */ SheetContent),
/* harmony export */   SheetDescription: () => (/* binding */ SheetDescription),
/* harmony export */   SheetFooter: () => (/* binding */ SheetFooter),
/* harmony export */   SheetHeader: () => (/* binding */ SheetHeader),
/* harmony export */   SheetTitle: () => (/* binding */ SheetTitle),
/* harmony export */   SheetTrigger: () => (/* binding */ SheetTrigger)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7589);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(79130);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11914);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12857);
/* __next_internal_client_entry_do_not_use__ Sheet,SheetTrigger,SheetClose,SheetContent,SheetHeader,SheetFooter,SheetTitle,SheetDescription auto */ 





const Sheet = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .fC;
const SheetTrigger = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Trigger */ .xz;
const SheetClose = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Close */ .x8;
const SheetPortal = ({ className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Portal */ .h_, {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)(className),
        ...props
    });
SheetPortal.displayName = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Portal */ .h_.displayName;
const SheetOverlay = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Overlay */ .aV, {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 bg-white/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 dark:bg-stone-950/80", className),
        ...props,
        ref: ref
    }));
SheetOverlay.displayName = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Overlay */ .aV.displayName;
const sheetVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_2__/* .cva */ .j)("fixed z-50 gap-4 bg-white p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500 dark:bg-stone-950", {
    variants: {
        side: {
            top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
            bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
            left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
            right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
        }
    },
    defaultVariants: {
        side: "right"
    }
});
const SheetContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ side = "right", className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SheetPortal, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SheetOverlay, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Content */ .VY, {
                ref: ref,
                className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)(sheetVariants({
                    side
                }), className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Close */ .x8, {
                        className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-stone-100 dark:ring-offset-stone-950 dark:focus:ring-stone-800 dark:data-[state=open]:bg-stone-800",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_5__/* .Cross2Icon */ .Pxu, {
                                className: "h-4 w-4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "sr-only",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
SheetContent.displayName = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Content */ .VY.displayName;
const SheetHeader = ({ className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("flex flex-col space-y-2 text-center sm:text-left", className),
        ...props
    });
SheetHeader.displayName = "SheetHeader";
const SheetFooter = ({ className, ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    });
SheetFooter.displayName = "SheetFooter";
const SheetTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Title */ .Dx, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("text-lg font-semibold text-stone-950 dark:text-stone-50", className),
        ...props
    }));
SheetTitle.displayName = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Title */ .Dx.displayName;
const SheetDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Description */ .dk, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("text-sm text-stone-500 dark:text-stone-400", className),
        ...props
    }));
SheetDescription.displayName = _radix_ui_react_dialog__WEBPACK_IMPORTED_MODULE_4__/* .Description */ .dk.displayName;



/***/ }),

/***/ 11992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProfilePage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(39100);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(64980);
// EXTERNAL MODULE: ./utils/supabaseRequests.ts + 1 modules
var supabaseRequests = __webpack_require__(78419);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js + 21 modules
var esm = __webpack_require__(54205);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(85839);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/ui/FollowButton.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/FollowButton.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const FollowButton = (__default__);
;// CONCATENATED MODULE: ./components/ui/UserBio.tsx

const UserBio_proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/UserBio.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: UserBio_esModule, $$typeof: UserBio_$$typeof } = UserBio_proxy;
const UserBio_default_ = UserBio_proxy.default;


/* harmony default export */ const UserBio = (UserBio_default_);
;// CONCATENATED MODULE: ./components/ui/avatar.tsx

const avatar_proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/avatar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: avatar_esModule, $$typeof: avatar_$$typeof } = avatar_proxy;
const avatar_default_ = avatar_proxy.default;

const e0 = avatar_proxy["Avatar"];

const e1 = avatar_proxy["AvatarImage"];

const e2 = avatar_proxy["AvatarFallback"];

// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(20203);
;// CONCATENATED MODULE: ./components/ui/sheet.tsx

const sheet_proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/sheet.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: sheet_esModule, $$typeof: sheet_$$typeof } = sheet_proxy;
const sheet_default_ = sheet_proxy.default;

const sheet_e0 = sheet_proxy["Sheet"];

const sheet_e1 = sheet_proxy["SheetTrigger"];

const sheet_e2 = sheet_proxy["SheetClose"];

const e3 = sheet_proxy["SheetContent"];

const e4 = sheet_proxy["SheetHeader"];

const e5 = sheet_proxy["SheetFooter"];

const e6 = sheet_proxy["SheetTitle"];

const e7 = sheet_proxy["SheetDescription"];

;// CONCATENATED MODULE: ./components/ui/label.tsx

const label_proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/label.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: label_esModule, $$typeof: label_$$typeof } = label_proxy;
const label_default_ = label_proxy.default;

const label_e0 = label_proxy["Label"];

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(25124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/FollowersSheet.tsx







async function FollowersSheet({ user, children }) {
    const followers = await (0,supabaseRequests.getFollowerList)({
        userId: user
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sheet_e0, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sheet_e1, {
                asChild: true,
                children: children
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e3, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(e4, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(e6, {
                            children: "Followers"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "mt-8",
                        children: [
                            (followers === undefined || followers.length === 0) && /*#__PURE__*/ jsx_runtime_.jsx(e7, {
                                children: "This user has no followers."
                            }),
                            followers?.map(async (f)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `/${(await esm/* clerkClient */.Ns.users.getUser(f.follower_id)).username}`,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex items-center gap-2 rounded-xl p-4 transition-colors ease-in-out hover:bg-stone-100 dark:hover:bg-stone-600/90",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(e1, {
                                                    src: (await esm/* clerkClient */.Ns.users.getUser(f.follower_id)).imageUrl
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(label_e0, {
                                                        className: "text-base",
                                                        children: `${(await esm/* clerkClient */.Ns.users.getUser(f.follower_id)).firstName}`
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(label_e0, {
                                                        className: "text-sm font-light text-stone-500 dark:text-stone-400",
                                                        children: `@${(await esm/* clerkClient */.Ns.users.getUser(f.follower_id)).username}`
                                                    })
                                                ]
                                            })
                                        ]
                                    }, f.follower_id)
                                }))
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/FollowingSheet.tsx







async function FollowingSheet({ user, children }) {
    const followings = await (0,supabaseRequests.getFollowingList)({
        userId: user
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sheet_e0, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sheet_e1, {
                asChild: true,
                children: children
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e3, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(e4, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(e6, {
                            children: "Following"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "mt-8",
                        children: [
                            (followings === undefined || followings.length === 0) && /*#__PURE__*/ jsx_runtime_.jsx(e7, {
                                children: "This user is following no one."
                            }),
                            followings?.map(async (f)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `/${(await esm/* clerkClient */.Ns.users.getUser(f.followee_id)).username}`,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "flex items-center gap-2 rounded-xl p-4 transition-colors ease-in-out hover:bg-stone-100 dark:hover:bg-stone-600/90",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(e1, {
                                                    src: (await esm/* clerkClient */.Ns.users.getUser(f.followee_id)).imageUrl
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(label_e0, {
                                                        className: "text-base",
                                                        children: `${(await esm/* clerkClient */.Ns.users.getUser(f.followee_id)).firstName}`
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(label_e0, {
                                                        className: "text-sm font-light text-stone-500 dark:text-stone-400",
                                                        children: `@${(await esm/* clerkClient */.Ns.users.getUser(f.followee_id)).username}`
                                                    })
                                                ]
                                            })
                                        ]
                                    }, f.followee_id)
                                }))
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/PreviewGallery.tsx
var PreviewGallery = __webpack_require__(46914);
;// CONCATENATED MODULE: ./app/[username]/UserCardContent.tsx




async function UserCardContent({ userId }) {
    const userRecipes = await (0,supabaseRequests.getUserFavoriteRecipes)({
        userId: userId
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3",
        children: userRecipes?.map((r)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: `recipe/${r?.id}/${r?.title.replace(/\s+/g, "-").toLowerCase()}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx(PreviewGallery/* GalleryItem */.L, {
                    title: r?.title || "",
                    description: "",
                    imageSrc: r?.image_url || "",
                    noDescription: true
                }, r?.title)
            }, r?.id))
    });
}

// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(50031);
;// CONCATENATED MODULE: ./app/[username]/UserCardContentSkeleton.tsx


function UserCardContentSkeleton({ numberOfSkeletons }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3",
        children: [
            ...Array(numberOfSkeletons)
        ].map((value, index)=>/*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                className: "h-[279px] w-[350px] sm:h-[368px] sm:w-[568px] md:h-[286px] md:w-[340px] lg:h-[338px] lg:w-[445px]"
            }, index))
    });
}

;// CONCATENATED MODULE: ./app/[username]/page.tsx














async function ProfilePage({ params }) {
    const { userId: currentUserId } = (0,esm/* auth */.I8)();
    const user = (await esm/* clerkClient */.Ns.users.getUserList({
        username: [
            params.username
        ]
    }))[0];
    if (user === undefined) {
        (0,navigation.notFound)();
    }
    const followsInit = await (0,supabaseRequests.checkFollower)({
        followerId: currentUserId,
        followeeId: user.id
    });
    const followerCount = await (0,supabaseRequests.getFollowerCount)({
        userId: user.id
    });
    const followingCount = await (0,supabaseRequests.getFollowingCount)({
        userId: user.id
    });
    const userRecipeCount = await (0,supabaseRequests.getUserFavRecipeCount)({
        userId: user.id
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* Card */.Zb, {
            className: "w-[400px] border-0 shadow-none dark:bg-transparent sm:my-8 sm:w-[620px] sm:rounded-xl sm:border sm:border-stone-200 sm:shadow sm:dark:border-stone-800 sm:dark:bg-stone-950 md:w-[750px] lg:w-[960px] xl:w-[1250px]",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardHeader */.Ol, {
                    className: "grid grid-cols-3 grid-rows-3 items-center gap-x-8 px-10 sm:grid-cols-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                            className: "col-span-1 row-span-2 h-20 w-20 self-center md:row-span-3 md:h-40 md:w-40 lg:h-40 lg:w-40",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(e1, {
                                src: user.imageUrl
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (0,utils.cn)("col-span-2 row-span-2 self-center sm:col-span-2 sm:row-span-2 md:col-span-3 md:row-span-1", currentUserId !== null && currentUserId !== user.id && "md:col-span-2"),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                                    className: "text-xl md:text-2xl lg:text-4xl",
                                    children: user.firstName + " " + user.lastName
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardDescription */.SZ, {
                                    className: "text-md md:text-xl lg:text-2xl",
                                    children: [
                                        "@",
                                        user.username
                                    ]
                                })
                            ]
                        }),
                        currentUserId !== null && currentUserId !== user.id && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-span-2 row-span-1 self-center sm:col-span-1 sm:row-span-2 md:row-span-1",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(FollowButton, {
                                currentUserId: currentUserId,
                                followeeId: user.id,
                                followsInit: followsInit
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "hidden font-medium md:block",
                            children: [
                                userRecipeCount,
                                " recipe",
                                userRecipeCount !== 1 && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "s"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FollowersSheet, {
                            user: user.id,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "hidden cursor-pointer font-medium md:block",
                                children: [
                                    followerCount,
                                    " follower",
                                    followerCount !== 1 && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "s"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FollowingSheet, {
                            user: user.id,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "hidden cursor-pointer font-medium md:block",
                                children: [
                                    followingCount,
                                    " following"
                                ]
                            })
                        }),
                        !(currentUserId !== null && currentUserId !== user.id && (user.unsafeMetadata.bio === "" || user.unsafeMetadata.bio === undefined)) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-span-4 md:col-span-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(UserBio, {
                                editable: !(currentUserId !== null && currentUserId !== user.id),
                                metadata: user.unsafeMetadata
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-span-4 flex items-center justify-between gap-8 font-medium md:hidden",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        userRecipeCount,
                                        " recipe",
                                        userRecipeCount !== 1 && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "s"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(FollowersSheet, {
                                    user: user.id,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "cursor-pointer",
                                        children: [
                                            followerCount,
                                            " follower",
                                            followerCount !== 1 && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "s"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(FollowingSheet, {
                                    user: user.id,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "cursor-pointer",
                                        children: [
                                            followingCount,
                                            " following"
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardContent */.aY, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_shared_subset.Suspense, {
                        fallback: /*#__PURE__*/ jsx_runtime_.jsx(UserCardContentSkeleton, {
                            numberOfSkeletons: userRecipeCount
                        }),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(UserCardContent, {
                            userId: user.id
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 50031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85839);


function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("animate-pulse rounded-md bg-stone-900/10 dark:bg-stone-50/10", className),
        ...props
    });
}



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [998,565,335,207,380,980,369,178,618,589,656,350,740,203,914], () => (__webpack_exec__(23292)));
module.exports = __webpack_exports__;

})();