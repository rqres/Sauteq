"use strict";
exports.id = 920;
exports.ids = [920];
exports.modules = {

/***/ 42596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  LunchIcon: () => (/* binding */ LunchIcon),
  "default": () => (/* binding */ EatPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
;// CONCATENATED MODULE: ./public/english_ingredients.json
const english_ingredients_namespaceObject = JSON.parse('{"a":[{"UsdaId":2,"name":"SALTED ANCHOVIES"},{"UsdaId":3,"name":"ANCHOVIES IN OIL"},{"UsdaId":4,"name":"VINEGAR"},{"UsdaId":5,"name":"WATER"},{"UsdaId":9,"name":"GARLIC (POWDER)"},{"UsdaId":10,"name":"LAMB"},{"UsdaId":17,"name":"APRICOTS"},{"UsdaId":23,"name":"LAUREL (DRIED)"},{"UsdaId":24,"name":"SOUR BLACK CHERRIES"},{"UsdaId":27,"name":"STARCH"},{"UsdaId":28,"name":"PINEAPPLE"},{"UsdaId":29,"name":"PINEAPPLE IN SYRUP"},{"UsdaId":30,"name":"DUCK"},{"UsdaId":38,"name":"RED LOBSTER"},{"UsdaId":39,"name":"ORANGES"},{"UsdaId":46,"name":"ASIAGO CHEESE"},{"UsdaId":47,"name":"FOREST ASPARAGUS"},{"UsdaId":51,"name":"EUROPEAN LOBSTER"},{"UsdaId":52,"name":"OATS"},{"UsdaId":63,"name":"CHARD"},{"UsdaId":65,"name":"CREAM PUFF"},{"UsdaId":66,"name":"LAGER BEER"},{"UsdaId":67,"name":"STOUT BEER"},{"UsdaId":69,"name":"SHORTBREAD BISCUITS"},{"UsdaId":73,"name":"CHOCOLATE COVERED BISCUITS"},{"UsdaId":74,"name":"SPONGE BISCUITS"},{"UsdaId":92,"name":"BRIE CHEESE"},{"UsdaId":98,"name":"MEAT AND VEGETABLES STOCK"},{"UsdaId":100,"name":"STOCK FROM CUBE"},{"UsdaId":106,"name":"BURRATA CHEESE"},{"UsdaId":108,"name":"BUTTER"},{"UsdaId":112,"name":"CACIOCAVALLO CHEESE"},{"UsdaId":129,"name":"SQUID"},{"UsdaId":133,"name":"CINNAMON"},{"UsdaId":136,"name":"PICKLED CAPERS"},{"UsdaId":137,"name":"KID"},{"UsdaId":144,"name":"ARTICHOKES"},{"UsdaId":147,"name":"ARTICHOKES IN OIL"},{"UsdaId":148,"name":"THISTLES"},{"UsdaId":149,"name":"CARROTS"},{"UsdaId":151,"name":"CHESTNUTS"},{"UsdaId":159,"name":"CAVIAR"},{"UsdaId":160,"name":"CAULIFLOWER"},{"UsdaId":164,"name":"GREEN CABBAGE"},{"UsdaId":165,"name":"CHICKPEAS (DRIED)"},{"UsdaId":166,"name":"CANNED CHICKPEAS"},{"UsdaId":167,"name":"CANDIED CITRON"},{"UsdaId":174,"name":"CUCUMBERS"},{"UsdaId":181,"name":"CHICORY"},{"UsdaId":186,"name":"MILK CHOCOLATE"},{"UsdaId":187,"name":"WHITE CHOCOLATE"},{"UsdaId":189,"name":"DARK CHOCOLATE"},{"UsdaId":216,"name":"SAUERKRAUT"},{"UsdaId":217,"name":"COCOA AND HAZELNUT CREAM"},{"UsdaId":220,"name":"CRESS"},{"UsdaId":240,"name":"BEEF EXTRACT"},{"UsdaId":242,"name":"BEANS"},{"UsdaId":247,"name":"STRING BEANS"},{"UsdaId":249,"name":"GUINEA-HEN"},{"UsdaId":252,"name":"OATMEAL"},{"UsdaId":253,"name":"CHESTNUT FLOUR"},{"UsdaId":254,"name":"CHICKPEA FLOUR"},{"UsdaId":255,"name":"COCONUT FLOUR"},{"UsdaId":256,"name":"WHEAT FLOUR (WHOLEMEAL)"},{"UsdaId":257,"name":"WHEAT FLOUR (00)"},{"UsdaId":258,"name":"DURUM WHEAT FLOUR"},{"UsdaId":259,"name":"BUCKWHEAT FLOUR"},{"UsdaId":260,"name":"CORN FLOUR"},{"UsdaId":262,"name":"RICE FLOUR"},{"UsdaId":263,"name":"RYE FLOUR (WHOLE RYE)"},{"UsdaId":268,"name":"BROAD BEAN"},{"UsdaId":270,"name":"FETA CHEESE"},{"UsdaId":276,"name":"FIGS"},{"UsdaId":280,"name":"DRIED FIGS"},{"UsdaId":281,"name":"FENNEL"},{"UsdaId":293,"name":"FONTINA CHEESE"},{"UsdaId":294,"name":"PROCESSED CHEESE"},{"UsdaId":304,"name":"CANNED MUSHROOMS"},{"UsdaId":306,"name":"BOLETUS RUFUS CEP"},{"UsdaId":307,"name":"CEPS"},{"UsdaId":309,"name":"DRIED MUSHROOMS"},{"UsdaId":313,"name":"HEN"},{"UsdaId":314,"name":"FRESHWATER SHRIMPS"},{"UsdaId":316,"name":"PRAWN"},{"UsdaId":318,"name":"CHOCOLATE ICE CREAM"},{"UsdaId":319,"name":"FRUIT ICE CREAM"},{"UsdaId":320,"name":"ICE MILK"},{"UsdaId":333,"name":"CRAB"},{"UsdaId":342,"name":"ENDIVE"},{"UsdaId":350,"name":"LARD"},{"UsdaId":351,"name":"WATER BUFFALO MILK"},{"UsdaId":353,"name":"ALMOND MILK"},{"UsdaId":354,"name":"SHEEP\'S MILK"},{"UsdaId":355,"name":"SOY MILK"},{"UsdaId":357,"name":"COW\'S MILK (FULL-FAT)"},{"UsdaId":365,"name":"COW\'S MILK (SKIMMED)"},{"UsdaId":371,"name":"LETTUCE"},{"UsdaId":379,"name":"LEMON"},{"UsdaId":390,"name":"MAYONNAISE"},{"UsdaId":391,"name":"CORN"},{"UsdaId":398,"name":"MARGARINE"},{"UsdaId":410,"name":"APPLE"},{"UsdaId":414,"name":"EGGPLANTS"},{"UsdaId":425,"name":"MERINGUE"},{"UsdaId":428,"name":"HONEY"},{"UsdaId":429,"name":"BLACKCURRANT"},{"UsdaId":431,"name":"MONTASIO CHEESE"},{"UsdaId":432,"name":"MULBERRY"},{"UsdaId":437,"name":"WATER BUFFALO MOZZARELLA"},{"UsdaId":441,"name":"HAZELNUTS"},{"UsdaId":443,"name":"NUTMEG"},{"UsdaId":448,"name":"COCONUT OIL"},{"UsdaId":452,"name":"OLIVE OIL"},{"UsdaId":455,"name":"PALM OIL"},{"UsdaId":464,"name":"BLACK OLIVES"},{"UsdaId":465,"name":"GREEN OLIVES"},{"UsdaId":470,"name":"NETTLE"},{"UsdaId":474,"name":"OYSTER"},{"UsdaId":481,"name":"COPPA-STUFFED ROLLED PANCETTA"},{"UsdaId":485,"name":"MILK BREAD"},{"UsdaId":491,"name":"RYE BREAD"},{"UsdaId":494,"name":"BREADCRUMBS"},{"UsdaId":495,"name":"WHOLEWHEAT BREAD"},{"UsdaId":496,"name":"TOASTED BREAD"},{"UsdaId":499,"name":"CREAM"},{"UsdaId":500,"name":"LONG-LIFE CREAM"},{"UsdaId":504,"name":"PARMESAN CHEESE"},{"UsdaId":511,"name":"SHORT PASTRY"},{"UsdaId":512,"name":"PUFF PASTRY"},{"UsdaId":516,"name":"POTATOES"},{"UsdaId":518,"name":"EARLY POTATOES"},{"UsdaId":525,"name":"ROMAN PECORINO CHEESE"},{"UsdaId":527,"name":"BLACK PEPPER"},{"UsdaId":531,"name":"PICKLED BELL PEPPERS"},{"UsdaId":532,"name":"PEAR"},{"UsdaId":533,"name":"PEACH"},{"UsdaId":536,"name":"SWORDFISH"},{"UsdaId":539,"name":"PINE NUTS"},{"UsdaId":541,"name":"CANNED PEAS"},{"UsdaId":543,"name":"FROZEN PEAS"},{"UsdaId":559,"name":"SALAD TOMATOES"},{"UsdaId":561,"name":"DRIED TOMATOES"},{"UsdaId":567,"name":"GRAPEFRUIT"},{"UsdaId":570,"name":"LEEKS"},{"UsdaId":574,"name":"HAM"},{"UsdaId":577,"name":"PROSCIUTTO"},{"UsdaId":586,"name":"PRUNES (DRIED)"},{"UsdaId":588,"name":"RED CHICORY"},{"UsdaId":590,"name":"FROG"},{"UsdaId":592,"name":"TURNIPS"},{"UsdaId":593,"name":"RADISHES"},{"UsdaId":595,"name":"RUM"},{"UsdaId":597,"name":"RED CURRANT"},{"UsdaId":598,"name":"SHEEP\'S MILK RICOTTA"},{"UsdaId":599,"name":"COW\'S MILK RICOTTA"},{"UsdaId":609,"name":"TURBOT"},{"UsdaId":612,"name":"ROCKET"},{"UsdaId":615,"name":"PORK SALAMI"},{"UsdaId":622,"name":"HUNGARIAN SALAMI"},{"UsdaId":625,"name":"SALMON"},{"UsdaId":626,"name":"SMOKED SALMON"},{"UsdaId":630,"name":"PORK SAUSAGE (FRESH)"},{"UsdaId":631,"name":"PORK SAUSAGE (DRIED)"},{"UsdaId":636,"name":"SALTED SARDINES"},{"UsdaId":638,"name":"SHALLOT"},{"UsdaId":642,"name":"MALT SYRUP"},{"UsdaId":644,"name":"OYSTER-PLANT"},{"UsdaId":646,"name":"CELERIAC"},{"UsdaId":649,"name":"CUTTLEFISH"},{"UsdaId":657,"name":"SOLE"},{"UsdaId":662,"name":"CHEESE SLICES"},{"UsdaId":664,"name":"BASS"},{"UsdaId":665,"name":"SPINACH"},{"UsdaId":717,"name":"BLACK TRUFFLE"},{"UsdaId":729,"name":"TUNA"},{"UsdaId":737,"name":"TORTELLINI (DRIED)"},{"UsdaId":738,"name":"RED MULLET"},{"UsdaId":739,"name":"TROUT"},{"UsdaId":747,"name":"GRAPES"},{"UsdaId":753,"name":"SWEET VERMOUTH"},{"UsdaId":754,"name":"DRY VERMOUTH"},{"UsdaId":755,"name":"WHITE WINE"},{"UsdaId":757,"name":"RED WINE"},{"UsdaId":768,"name":"CLAM"},{"UsdaId":772,"name":"FRANKFURTER"},{"UsdaId":781,"name":"SAFFRON"},{"UsdaId":783,"name":"YELLOW SQUASH"},{"UsdaId":784,"name":"SUGAR"},{"UsdaId":786,"name":"ZUCCHINI"},{"UsdaId":793,"name":"CARNE SALADA SALTED MEAT"},{"UsdaId":794,"name":"BALSAMIC VINEGAR"},{"UsdaId":799,"name":"NDUJA SAUSAGE"},{"UsdaId":800,"name":"TOMATO SAUCE"},{"UsdaId":802,"name":"BEEF"},{"UsdaId":810,"name":"DURUM WHEAT PASTA"},{"UsdaId":814,"name":"STAR ANISE"},{"UsdaId":815,"name":"CLOVES"},{"UsdaId":816,"name":"ICING SUGAR"},{"UsdaId":817,"name":"WHITE PEPPER"},{"UsdaId":818,"name":"SCALLOPS"},{"UsdaId":828,"name":"CELARY"},{"UsdaId":829,"name":"MUSTARD"},{"UsdaId":830,"name":"SESAM"},{"UsdaId":834,"name":"GINGER"},{"UsdaId":863,"name":"TUSCAN PECORINO CHEESE"},{"UsdaId":890,"name":"TUSCAN BREAD"},{"UsdaId":952,"name":"LUSIA SALAD"},{"UsdaId":981,"name":"BARAGGIA BIELLESE AND VERCELLESE RICE"},{"UsdaId":1011,"name":"VAL DI NON APPLE"},{"UsdaId":1083,"name":"TREVISO RED CHICORY"},{"UsdaId":1087,"name":"VIALONE VERONESE DWARF RICE"},{"UsdaId":1357,"name":"AROMATIC VINEGAR"},{"UsdaId":1358,"name":"MALT VINEGAR"},{"UsdaId":1359,"name":"APPLE VINEGAR"},{"UsdaId":1360,"name":"WINE VINEGAR"},{"UsdaId":1361,"name":"WHITE WINE VINEGAR"},{"UsdaId":1362,"name":"RED WINE VINEGAR"},{"UsdaId":1363,"name":"BRANDY"},{"UsdaId":1366,"name":"GARLIC"},{"UsdaId":1367,"name":"APRICOT IN SYRUP"},{"UsdaId":1368,"name":"DRIED APRICOTS"},{"UsdaId":1369,"name":"EGG WHITE"},{"UsdaId":1371,"name":"ALCOHOL"},{"UsdaId":1374,"name":"LAUREL"},{"UsdaId":1375,"name":"SOUR BLACK CHERRIES IN SYRUP"},{"UsdaId":1380,"name":"CORN STARCH"},{"UsdaId":1381,"name":"CASHEW NUTS"},{"UsdaId":1382,"name":"DILL"},{"UsdaId":1384,"name":"ANISE"},{"UsdaId":1385,"name":"SWEETBREADS"},{"UsdaId":1389,"name":"PEANUTS"},{"UsdaId":1390,"name":"CANDIED ORANGE"},{"UsdaId":1391,"name":"AROMAS"},{"UsdaId":1392,"name":"NATURAL FLAVORS"},{"UsdaId":1394,"name":"ASPARAGUS"},{"UsdaId":1397,"name":"JUNIPER BERRIES"},{"UsdaId":1399,"name":"BEETROOT"},{"UsdaId":1401,"name":"BECHAMEL SAUCE"},{"UsdaId":1402,"name":"BIRCH"},{"UsdaId":1404,"name":"BICARBONATE OF SODA"},{"UsdaId":1405,"name":"BEER"},{"UsdaId":1406,"name":"BISCUITS"},{"UsdaId":1407,"name":"AMARETTI BISCUITS"},{"UsdaId":1408,"name":"CAT TONGUE BISCUITS"},{"UsdaId":1409,"name":"DRY BISCUITS"},{"UsdaId":1415,"name":"BOTARGO"},{"UsdaId":1416,"name":"MULLET BOTARGO"},{"UsdaId":1420,"name":"BROCCOLI"},{"UsdaId":1421,"name":"MEAT STOCK"},{"UsdaId":1422,"name":"SHELLFISH STOCK"},{"UsdaId":1423,"name":"BEEF STOCK"},{"UsdaId":1424,"name":"FISH STOCK"},{"UsdaId":1425,"name":"CHICKEN STOCK"},{"UsdaId":1426,"name":"VEGETABLE STOCK"},{"UsdaId":1429,"name":"BUTTER OIL"},{"UsdaId":1430,"name":"CLARIFIED BUTTER"},{"UsdaId":1431,"name":"COCOA BUTTER"},{"UsdaId":1432,"name":"COCOA"},{"UsdaId":1433,"name":"SWEETENED COCOA POWDER"},{"UsdaId":1434,"name":"COFFEE"},{"UsdaId":1441,"name":"MANTIS SHRIMP"},{"UsdaId":1442,"name":"CAPERS"},{"UsdaId":1445,"name":"CAPERS IN OIL"},{"UsdaId":1446,"name":"CAPON"},{"UsdaId":1447,"name":"STAR FRUIT"},{"UsdaId":1449,"name":"CANNED ARTICHOKES"},{"UsdaId":1450,"name":"CARDAMOM"},{"UsdaId":1452,"name":"OSTRICH MEAT"},{"UsdaId":1454,"name":"MINCED VEAL"},{"UsdaId":1456,"name":"MINCED MEAT"},{"UsdaId":1461,"name":"RACK OF LAMB"},{"UsdaId":1462,"name":"CAROBS"},{"UsdaId":1463,"name":"BLACK CAVIAR"},{"UsdaId":1464,"name":"WHITE CABBAGE"},{"UsdaId":1465,"name":"SAVOY CABBAGE"},{"UsdaId":1466,"name":"CAYENNE PEPPER"},{"UsdaId":1467,"name":"CHICKPEAS"},{"UsdaId":1469,"name":"CITRON"},{"UsdaId":1470,"name":"CHERVIL"},{"UsdaId":1472,"name":"PICKLED CUCUMBERS"},{"UsdaId":1478,"name":"WAFERS"},{"UsdaId":1482,"name":"CHERRY"},{"UsdaId":1483,"name":"BRANDIED CHERRIES"},{"UsdaId":1484,"name":"MARASCHINO CHERRIES"},{"UsdaId":1485,"name":"CANDIED CHERRY"},{"UsdaId":1487,"name":"CHERRIES IN SYRUP"},{"UsdaId":1488,"name":"CAULIFLOWER FLORET"},{"UsdaId":1489,"name":"RAPINI"},{"UsdaId":1491,"name":"CHOCOLATE"},{"UsdaId":1492,"name":"ONION"},{"UsdaId":1493,"name":"WHITE ONION"},{"UsdaId":1494,"name":"RED TROPEA ONION"},{"UsdaId":1496,"name":"RED ONION"},{"UsdaId":1497,"name":"PICKLED BABY ONIONS"},{"UsdaId":1499,"name":"SPRING ONION"},{"UsdaId":1501,"name":"LEMONGRASS"},{"UsdaId":1502,"name":"COCONUT"},{"UsdaId":1503,"name":"SHRIMP TAILS"},{"UsdaId":1504,"name":"PRAWN TAILS"},{"UsdaId":1506,"name":"FISH GLUE"},{"UsdaId":1508,"name":"DOUBLE CONCENTRATE TOMATO PUREE"},{"UsdaId":1509,"name":"TOMATO PUREE"},{"UsdaId":1511,"name":"CORIANDER"},{"UsdaId":1513,"name":"BEEF HAM"},{"UsdaId":1514,"name":"ENTRECÔTE"},{"UsdaId":1516,"name":"PORK RIND"},{"UsdaId":1517,"name":"MUSSELS"},{"UsdaId":1518,"name":"COCOA CREAM"},{"UsdaId":1519,"name":"WHITE COCOA CREAM"},{"UsdaId":1527,"name":"RICE CUSTARD"},{"UsdaId":1528,"name":"CUSTARD"},{"UsdaId":1530,"name":"TOASTS"},{"UsdaId":1532,"name":"CUMIN"},{"UsdaId":1533,"name":"PALMITO"},{"UsdaId":1534,"name":"ARTICHOKE HEARTS"},{"UsdaId":1537,"name":"TURMERIC"},{"UsdaId":1539,"name":"VEGETABLE CUBE"},{"UsdaId":1540,"name":"DATES"},{"UsdaId":1541,"name":"TARRAGON"},{"UsdaId":1543,"name":"EDAMER CHEESE"},{"UsdaId":1546,"name":"CHIVES"},{"UsdaId":1547,"name":"LEMON VERBENA"},{"UsdaId":1549,"name":"ALMOND ESSENCE"},{"UsdaId":1551,"name":"TAMARIND EXTRACT"},{"UsdaId":1552,"name":"HARICOT BEANS"},{"UsdaId":1553,"name":"ROMAN BEANS"},{"UsdaId":1555,"name":"CANNELLINI BEANS"},{"UsdaId":1558,"name":"FLOUR"},{"UsdaId":1564,"name":"ALMOND FLOUR"},{"UsdaId":1565,"name":"RYE FLOUR"},{"UsdaId":1569,"name":"COCOA BEANS"},{"UsdaId":1570,"name":"POTATO STARCH"},{"UsdaId":1571,"name":"CHICKEN LIVERS"},{"UsdaId":1572,"name":"VEAL LIVER"},{"UsdaId":1574,"name":"VEAL TOP ROUND"},{"UsdaId":1575,"name":"GRASS"},{"UsdaId":1577,"name":"FENUGREEK"},{"UsdaId":1584,"name":"CICELY"},{"UsdaId":1589,"name":"ZUCCHINI FLOWER"},{"UsdaId":1591,"name":"COW MILK CHEESE"},{"UsdaId":1595,"name":"CREAMY CHEESE"},{"UsdaId":1601,"name":"GORGONZOLA CHEESE"},{"UsdaId":1602,"name":"GRANA CHEESE"},{"UsdaId":1604,"name":"GRUYERE CHEESE"},{"UsdaId":1607,"name":"SEMI-RIPE CHEESE"},{"UsdaId":1608,"name":"PHILADELPHIA CREAM CHEESE"},{"UsdaId":1609,"name":"PROVOLA CHEESE"},{"UsdaId":1610,"name":"ROBIOLA CHEESE"},{"UsdaId":1611,"name":"ROQUEFORT CHEESE"},{"UsdaId":1612,"name":"SCAMORZA CHEESE"},{"UsdaId":1614,"name":"TALEGGIO CHEESE"},{"UsdaId":1615,"name":"NON-DAIRY CHEESE"},{"UsdaId":1616,"name":"WILD STRAWBERRIES"},{"UsdaId":1624,"name":"WILD FRUITS"},{"UsdaId":1625,"name":"SEAFOOD"},{"UsdaId":1627,"name":"MUSHROOMS IN OIL"},{"UsdaId":1628,"name":"MUSHROOMS"},{"UsdaId":1630,"name":"CHANTERELLE MUSHROOMS"},{"UsdaId":1633,"name":"SHRIMPS"},{"UsdaId":1634,"name":"KING PRAWNS"},{"UsdaId":1637,"name":"GELATIN"},{"UsdaId":1638,"name":"APRICOT JELLY"},{"UsdaId":1639,"name":"CURRANT JELLY"},{"UsdaId":1640,"name":"GELATIN SHEETS"},{"UsdaId":1641,"name":"INSTANT GELATIN"},{"UsdaId":1642,"name":"PLAIN ICE CREAM"},{"UsdaId":1643,"name":"PLAIN ICE CREAM"},{"UsdaId":1644,"name":"VANILLA ICE CREAM"},{"UsdaId":1645,"name":"LEMON ICE CREAM"},{"UsdaId":1646,"name":"BAMBOO SHOOTS"},{"UsdaId":1647,"name":"SOY SPROUTS"},{"UsdaId":1653,"name":"APRICOT GLAZE"},{"UsdaId":1654,"name":"CHOCOLATE GLAZE"},{"UsdaId":1655,"name":"GLUCOSE"},{"UsdaId":1657,"name":"CHOCOLATE CHIPS"},{"UsdaId":1664,"name":"CHEEK LARD"},{"UsdaId":1667,"name":"BELGIAN ENDIVE"},{"UsdaId":1675,"name":"SMOKED LARD"},{"UsdaId":1677,"name":"MILK"},{"UsdaId":1680,"name":"COCONUT MILK"},{"UsdaId":1682,"name":"FULL-FAT POWDERED MILK"},{"UsdaId":1684,"name":"SKIMMED POWDERED MILK"},{"UsdaId":1685,"name":"LAVENDER"},{"UsdaId":1687,"name":"LENTILS"},{"UsdaId":1688,"name":"YEAST"},{"UsdaId":1689,"name":"BREWER\'S YEAST"},{"UsdaId":1691,"name":"VANILLA-FLAVOURED BAKING POWDER"},{"UsdaId":1703,"name":"SMOKED LOIN OF PORK"},{"UsdaId":1704,"name":"LOIN OF PORK"},{"UsdaId":1706,"name":"TRENTINO LUCANICA SAUSAGE"},{"UsdaId":1707,"name":"LUPINS"},{"UsdaId":1708,"name":"HOP"},{"UsdaId":1709,"name":"MACE"},{"UsdaId":1711,"name":"PORK"},{"UsdaId":1713,"name":"MALT"},{"UsdaId":1714,"name":"CORN MALT"},{"UsdaId":1716,"name":"KUMQUAT"},{"UsdaId":1717,"name":"TANGERINE"},{"UsdaId":1718,"name":"ALMOND"},{"UsdaId":1719,"name":"BITTER ALMOND"},{"UsdaId":1721,"name":"MARASCHINO LIQUEUR"},{"UsdaId":1722,"name":"JAM"},{"UsdaId":1723,"name":"APRICOT JAM"},{"UsdaId":1724,"name":"SOUR CHERRY JAM"},{"UsdaId":1725,"name":"ORANGE MARMALADE"},{"UsdaId":1726,"name":"CHESTNUT JAM"},{"UsdaId":1727,"name":"RASPBERRY JAM"},{"UsdaId":1728,"name":"PEACH JAM"},{"UsdaId":1730,"name":"MARRONS GLACÉS"},{"UsdaId":1733,"name":"WHITE SHRIMPS"},{"UsdaId":1734,"name":"POMEGRANATE"},{"UsdaId":1736,"name":"OBLONG EGGPLANT"},{"UsdaId":1737,"name":"RENNET APPLE"},{"UsdaId":1738,"name":"MOLASSES"},{"UsdaId":1739,"name":"GRANNY SMITH APPLE"},{"UsdaId":1740,"name":"GOLDEN APPLE"},{"UsdaId":1741,"name":"LEMON-BALM"},{"UsdaId":1742,"name":"MELON"},{"UsdaId":1743,"name":"MINT"},{"UsdaId":1744,"name":"PENNYROYAL"},{"UsdaId":1745,"name":"OX BONE MARROW"},{"UsdaId":1746,"name":"ACACIA HONEY"},{"UsdaId":1747,"name":"DANDELION HONEY"},{"UsdaId":1749,"name":"MIXED GREEN SALAD"},{"UsdaId":1754,"name":"INSIDE OF LOAF"},{"UsdaId":1756,"name":"BLACKBERRY"},{"UsdaId":1758,"name":"MUSCKY OCTOPUS"},{"UsdaId":1759,"name":"SWEET FRUIT PICKLES"},{"UsdaId":1760,"name":"CITRON PICKLE"},{"UsdaId":1762,"name":"CONCENTRATED GRAPE MUST"},{"UsdaId":1766,"name":"HAKE"},{"UsdaId":1767,"name":"WALNUTS"},{"UsdaId":1769,"name":"OIL"},{"UsdaId":1770,"name":"PEANUT OIL"},{"UsdaId":1771,"name":"SUNFLOWER OIL"},{"UsdaId":1772,"name":"CORN OIL"},{"UsdaId":1773,"name":"ALMOND OIL"},{"UsdaId":1774,"name":"SEED OIL"},{"UsdaId":1775,"name":"SESAME SEED OIL"},{"UsdaId":1776,"name":"EXTRA VIRGIN OLIVE OIL"},{"UsdaId":1777,"name":"OLIVE"},{"UsdaId":1779,"name":"GAETA OLIVES"},{"UsdaId":1783,"name":"GILTHEAD BREAM"},{"UsdaId":1785,"name":"SANDWICH BREAD"},{"UsdaId":1788,"name":"BREAD"},{"UsdaId":1791,"name":"HOMEMADE BREAD"},{"UsdaId":1793,"name":"BLACK BREAD"},{"UsdaId":1794,"name":"BREAD ROLLS"},{"UsdaId":1795,"name":"WHIPPED CREAM"},{"UsdaId":1796,"name":"NON-DAIRY CREAM"},{"UsdaId":1797,"name":"PAPAYA"},{"UsdaId":1798,"name":"HOT PAPRIKA"},{"UsdaId":1799,"name":"SWEET PAPRIKA"},{"UsdaId":1800,"name":"PULPED TOMATOES"},{"UsdaId":1801,"name":"HAZELNUT PASTA"},{"UsdaId":1802,"name":"BRICK PASTRY"},{"UsdaId":1803,"name":"SHORT CRUST PASTRY"},{"UsdaId":1804,"name":"ANCHOVY PASTE"},{"UsdaId":1805,"name":"OLIVE PASTE"},{"UsdaId":1806,"name":"COCOA PASTE"},{"UsdaId":1807,"name":"ALMOND PASTE"},{"UsdaId":1808,"name":"WALNUT PASTA"},{"UsdaId":1809,"name":"BLACK TRUFFLE PASTA"},{"UsdaId":1814,"name":"PEPPER"},{"UsdaId":1816,"name":"RED CHILI PEPPER"},{"UsdaId":1820,"name":"DRIED CHILI PEPPERS"},{"UsdaId":1824,"name":"BELL PEPPER"},{"UsdaId":1825,"name":"YELLOW BELL PEPPER"},{"UsdaId":1826,"name":"RED BELL PEPPER"},{"UsdaId":1828,"name":"BELL PEPPERS IN OIL"},{"UsdaId":1829,"name":"GREEN BELL PEPPER"},{"UsdaId":1831,"name":"PINK PEPPER"},{"UsdaId":1832,"name":"GREEN PEPPER"},{"UsdaId":1835,"name":"PEACHES IN SYRUP"},{"UsdaId":1838,"name":"DUCK BREAST"},{"UsdaId":1840,"name":"CHICKEN BREAST"},{"UsdaId":1841,"name":"SWEET PEAS"},{"UsdaId":1842,"name":"PISTACHIOS"},{"UsdaId":1844,"name":"OCTOPUSES"},{"UsdaId":1845,"name":"CHICKEN"},{"UsdaId":1849,"name":"VENISON MUSCLE"},{"UsdaId":1852,"name":"CRAB MEAT"},{"UsdaId":1853,"name":"PORK MUSCLE"},{"UsdaId":1854,"name":"BEEF MUSCLE"},{"UsdaId":1855,"name":"CRUSHED TOMATOES"},{"UsdaId":1856,"name":"VEAL MUSCLE"},{"UsdaId":1857,"name":"CAROB POWDER"},{"UsdaId":1858,"name":"CHERRY TOMATOES"},{"UsdaId":1862,"name":"PACHINO CHERRY TOMATOES"},{"UsdaId":1863,"name":"PEELED TOMATOES"},{"UsdaId":1865,"name":"VINE TOMATOES"},{"UsdaId":1866,"name":"GREEN TOMATOES"},{"UsdaId":1867,"name":"TOMATO"},{"UsdaId":1869,"name":"DATE TOMATOES"},{"UsdaId":1876,"name":"ASPARAGUS TIPS"},{"UsdaId":1878,"name":"RHUBARB"},{"UsdaId":1879,"name":"CHICORY"},{"UsdaId":1881,"name":"HORSERADISH"},{"UsdaId":1882,"name":"CHICKEN GIBLETS"},{"UsdaId":1883,"name":"CURRANT"},{"UsdaId":1884,"name":"RICOTTA CHEESE"},{"UsdaId":1885,"name":"SMOKED RICOTTA CHEESE"},{"UsdaId":1886,"name":"ROMAN RICOTTA CHEESE"},{"UsdaId":1887,"name":"SALTED RICOTTA CHEESE"},{"UsdaId":1888,"name":"CARNAROLI RICE"},{"UsdaId":1889,"name":"KIDNEY"},{"UsdaId":1895,"name":"SALAMI"},{"UsdaId":1896,"name":"SMALL SALAMI"},{"UsdaId":1903,"name":"VINEGAR SAUCE"},{"UsdaId":1904,"name":"SOY SAUCE"},{"UsdaId":1907,"name":"KETCHUP"},{"UsdaId":1908,"name":"WORCESTER SAUCE"},{"UsdaId":1909,"name":"PROSCIUTTO SAUSAGES"},{"UsdaId":1912,"name":"JOHN DORY"},{"UsdaId":1913,"name":"SAVORY"},{"UsdaId":1916,"name":"SARDINES IN OIL"},{"UsdaId":1917,"name":"PRAWNS"},{"UsdaId":1918,"name":"SOUR CHERRY SYRUP"},{"UsdaId":1919,"name":"ORGEAT SYRUP"},{"UsdaId":1920,"name":"STRAWBERRY SYRUP"},{"UsdaId":1921,"name":"GLUCOSE SYRUP"},{"UsdaId":1922,"name":"GRENADINE SYRUP"},{"UsdaId":1923,"name":"LEMON SYRUP"},{"UsdaId":1924,"name":"TANGERINE SYRUP"},{"UsdaId":1925,"name":"SUGAR SYRUP"},{"UsdaId":1926,"name":"RED SCORPIONFISH"},{"UsdaId":1927,"name":"ORANGE PEEL"},{"UsdaId":1928,"name":"LIME PEEL"},{"UsdaId":1931,"name":"WHITE CELERY"},{"UsdaId":1932,"name":"GREEN CELERY"},{"UsdaId":1933,"name":"SELTERS"},{"UsdaId":1937,"name":"FENNEL SEEDS"},{"UsdaId":1938,"name":"CHIA SEEDS"},{"UsdaId":1939,"name":"POPPY SEEDS"},{"UsdaId":1940,"name":"MUSTARD SEEDS"},{"UsdaId":1941,"name":"WHEAT FLOUR"},{"UsdaId":1942,"name":"SEMOLINA"},{"UsdaId":1945,"name":"SWEET MUSTARD"},{"UsdaId":1946,"name":"STRONG MUSTARD"},{"UsdaId":1947,"name":"FRENCH MUSTARD"},{"UsdaId":1948,"name":"ENGLISH MUSTARD"},{"UsdaId":1949,"name":"SPICY MUSTARD"},{"UsdaId":1955,"name":"SOY"},{"UsdaId":1957,"name":"PICKLED VEGETABLES"},{"UsdaId":1965,"name":"APRICOT JUICE"},{"UsdaId":1966,"name":"PINEAPPLE JUICE"},{"UsdaId":1967,"name":"ORANGE JUICE"},{"UsdaId":1968,"name":"CLEAR GRAPE JUICE"},{"UsdaId":1969,"name":"BANANA JUICE"},{"UsdaId":1970,"name":"BEETROOT JUICE"},{"UsdaId":1971,"name":"CARROT JUICE"},{"UsdaId":1972,"name":"CITRON JUICE"},{"UsdaId":1973,"name":"CHERRY JUICE"},{"UsdaId":1974,"name":"FIG JUICE"},{"UsdaId":1975,"name":"FENNEL JUICE"},{"UsdaId":1976,"name":"STRAWBERRY JUICE"},{"UsdaId":1977,"name":"KIWI JUICE"},{"UsdaId":1978,"name":"RASPBERRY JUICE"},{"UsdaId":1979,"name":"LIME JUICE"},{"UsdaId":1980,"name":"LEMON JUICE"},{"UsdaId":1981,"name":"LITCHEE JUICE"},{"UsdaId":1982,"name":"CLEMENTINE JUICE"},{"UsdaId":1983,"name":"MANGO JUICE"},{"UsdaId":1984,"name":"APPLE JUICE"},{"UsdaId":1985,"name":"BLUEBERRY JUICE"},{"UsdaId":1986,"name":"PAPAYA JUICE"},{"UsdaId":1987,"name":"BELL PEPPER JUICE"},{"UsdaId":1988,"name":"PEAR JUICE"},{"UsdaId":1989,"name":"PEACH JUICE"},{"UsdaId":1990,"name":"TOMATO JUICE"},{"UsdaId":1991,"name":"CURRANT JUICE"},{"UsdaId":1992,"name":"CELERY JUICE"},{"UsdaId":1993,"name":"PUMPKIN JUICE"},{"UsdaId":1996,"name":"SNOWPEAS"},{"UsdaId":2001,"name":"TEA"},{"UsdaId":2002,"name":"THYME"},{"UsdaId":2006,"name":"JERUSALEM ARTICHOKE"},{"UsdaId":2008,"name":"TOSELLA CHEESE"},{"UsdaId":2014,"name":"EGG YOLK"},{"UsdaId":2015,"name":"EGGS"},{"UsdaId":2016,"name":"LUMPFISH ROE"},{"UsdaId":2019,"name":"HARD BOILED EGGS"},{"UsdaId":2022,"name":"WHITE GRAPES"},{"UsdaId":2023,"name":"RED GRAPES"},{"UsdaId":2024,"name":"RAISINS"},{"UsdaId":2025,"name":"SULTANAS"},{"UsdaId":2026,"name":"VANILLA"},{"UsdaId":2028,"name":"VANILLIN"},{"UsdaId":2033,"name":"WHITE VERMOUTH"},{"UsdaId":2034,"name":"RED VERMOUTH"},{"UsdaId":2037,"name":"WINE"},{"UsdaId":2038,"name":"BAROLO WINE"},{"UsdaId":2039,"name":"SWEET WHITE WINE"},{"UsdaId":2040,"name":"DRY WHITE WINE"},{"UsdaId":2041,"name":"CHAMPAGNE"},{"UsdaId":2043,"name":"MADERA WINE"},{"UsdaId":2045,"name":"MOSCATO WINE"},{"UsdaId":2046,"name":"PORT"},{"UsdaId":2047,"name":"RED PORT"},{"UsdaId":2049,"name":"DRY RED WINE"},{"UsdaId":2050,"name":"SPUMANTE"},{"UsdaId":2051,"name":"ASTI SPUMANTE"},{"UsdaId":2052,"name":"SPUMANTE BRUT"},{"UsdaId":2053,"name":"VERDUZZO"},{"UsdaId":2054,"name":"VIN SANTO SWEET WINE"},{"UsdaId":2055,"name":"CARPET SHELL CLAMS"},{"UsdaId":2056,"name":"PORK FRANKFURTER"},{"UsdaId":2058,"name":"YOGHURT"},{"UsdaId":2062,"name":"LOW-FAT YOGHURT"},{"UsdaId":2064,"name":"CANE SUGAR"},{"UsdaId":2067,"name":"VANILLA SUGAR"}]}');
;// CONCATENATED MODULE: ./utils/ingredientData.ts
// Import the JSON object containing ingredient data

// Create a hashmap to store the ingredient data
const ingredientMap = {};
// Function to parse the JSON object and create the hashmap
function createIngredientMap() {
    for (const ingredient of english_ingredients_namespaceObject.a){
        const { UsdaId, name } = ingredient;
        ingredientMap[UsdaId] = name;
    }
}
// Call the function to create the hashmap
createIngredientMap();
// Export the ingredientMap for use in other files
/* harmony default export */ const ingredientData = (ingredientMap);

// EXTERNAL MODULE: ./utils/supabaseRequests.ts
var supabaseRequests = __webpack_require__(76537);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 54 modules
var esm = __webpack_require__(3271);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 5 modules
var AnimatePresence = __webpack_require__(30569);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 192 modules
var motion = __webpack_require__(31691);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
// EXTERNAL MODULE: ./node_modules/fuse.js/dist/fuse.common.js
var fuse_common = __webpack_require__(96613);
var fuse_common_default = /*#__PURE__*/__webpack_require__.n(fuse_common);
;// CONCATENATED MODULE: ./hooks/useSearch.ts


function useSearch({ dataSet, keys }) {
    const [searchQuery, setSearchQuery] = (0,react_experimental_.useState)("");
    const fuse = (0,react_experimental_.useMemo)(()=>{
        const options = {
            includeScore: true,
            keys,
            threshold: 0.4
        };
        return new (fuse_common_default())(dataSet, options);
    }, [
        dataSet,
        keys
    ]);
    const results = (0,react_experimental_.useMemo)(()=>{
        if (!searchQuery) return [];
        const searchResults = fuse.search(searchQuery, {
            limit: 10
        });
        return searchResults.map((sr)=>sr.item);
    }, [
        fuse,
        searchQuery
    ]);
    return {
        searchQuery,
        setSearchQuery,
        results
    };
}

// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(44368);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(70737);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-checkbox/dist/index.mjs + 1 modules
var dist = __webpack_require__(97312);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
;// CONCATENATED MODULE: ./components/ui/checkbox.tsx
/* __next_internal_client_entry_do_not_use__ Checkbox auto */ 




const Checkbox = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Root */.fC, {
        ref: ref,
        className: (0,utils.cn)("peer h-4 w-4 shrink-0 rounded-sm border border-stone-900 shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-stone-900 data-[state=checked]:text-stone-50 dark:border-stone-800 dark:focus-visible:ring-stone-800 dark:data-[state=checked]:bg-stone-50 dark:data-[state=checked]:text-stone-900", className),
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* Indicator */.z$, {
            className: (0,utils.cn)("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CheckIcon */.nQG, {
                className: "h-4 w-4"
            })
        })
    }));
Checkbox.displayName = dist/* Root */.fC.displayName;


;// CONCATENATED MODULE: ./components/ui/input.tsx



const Input = /*#__PURE__*/ react_experimental_.forwardRef(({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("input", {
        type: type,
        className: (0,utils.cn)("flex h-9 w-full rounded-md border border-stone-200 bg-white px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-stone-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-400 disabled:cursor-not-allowed disabled:opacity-50 dark:border-stone-800 dark:bg-stone-950 dark:placeholder:text-stone-400 dark:focus-visible:ring-stone-800", className),
        ref: ref,
        ...props
    });
});
Input.displayName = "Input";


// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(81396);
;// CONCATENATED MODULE: ./components/AnimatedIngredientItem.tsx


let base = 4;
let t = (d)=>d * base;
function AnimatedIngredientItem({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
        layout: true,
        className: "relative",
        initial: {
            height: 0,
            opacity: 0
        },
        animate: {
            height: "auto",
            opacity: 1,
            transition: {
                type: "spring",
                bounce: 0.25,
                opacity: {
                    delay: t(0.025)
                }
            }
        },
        exit: {
            height: 0,
            opacity: 0
        },
        transition: {
            duration: t(0.15),
            type: "spring",
            bounce: 0,
            opacity: {
                duration: t(0.03)
            }
        },
        children: children
    });
}

// EXTERNAL MODULE: ./components/RecipeSheet.tsx + 1 modules
var RecipeSheet = __webpack_require__(42686);
// EXTERNAL MODULE: ./app/actions.ts
var actions = __webpack_require__(12479);
;// CONCATENATED MODULE: ./app/eat/page.tsx
/* __next_internal_client_entry_do_not_use__ default,LunchIcon auto */ 

















const LunchIcon = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "lucide lucide-sandwich",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M3 11v3a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-3"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12 19H4a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-3.83"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "m3 11 7.77-6.04a2 2 0 0 1 2.46 0L21 11H3Z"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12.97 19.77 7 15h12.5l-3.75 4.5a2 2 0 0 1-2.78.27Z"
            })
        ]
    });
const MealTypeButton = ({ mealType, mealTypeState, setMealType })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (0,utils.cn)("grid grow cursor-pointer place-items-center gap-1 rounded-md border border-stone-200 py-3 shadow-sm transition-colors duration-300 ease-in-out hover:bg-stone-100/60 dark:border-stone-800 dark:bg-stone-950 dark:hover:bg-stone-800/60", mealTypeState === mealType && "border-stone-400 bg-stone-100/50 text-stone-900 dark:border-stone-200 dark:bg-stone-800/50 dark:text-stone-200"),
        onClick: ()=>{
            if (mealTypeState === mealType) {
                setMealType("any");
            } else {
                setMealType(mealType);
            }
        },
        children: [
            mealType === "breakfast" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* EggFried */.o4d, {}),
                    "Breakfast"
                ]
            }),
            mealType === "lunch" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(LunchIcon, {}),
                    "Lunch"
                ]
            }),
            mealType === "dinner" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Drumstick */.jDc, {}),
                    "Dinner"
                ]
            })
        ]
    });
function EatPage() {
    const { isLoaded, userId, getToken } = (0,esm/* useAuth */.aC)();
    const { searchQuery, setSearchQuery, results } = useSearch({
        dataSet: english_ingredients_namespaceObject.a,
        keys: [
            "name"
        ]
    });
    const [selection, setSelection] = (0,react_experimental_.useState)([]);
    const [recipeView, setRecipeView] = (0,react_experimental_.useState)(false);
    const [formView, setFormView] = (0,react_experimental_.useState)(true);
    const [title, setTitle] = (0,react_experimental_.useState)("");
    const [description, setDescription] = (0,react_experimental_.useState)("");
    const [body, setBody] = (0,react_experimental_.useState)(null);
    const [image, setImage] = (0,react_experimental_.useState)("");
    const [loading, setLoading] = (0,react_experimental_.useState)(false);
    const [mealType, setMealType] = (0,react_experimental_.useState)("any");
    const searchBoxRef = (0,react_experimental_.useRef)(null);
    const recipeRef = (0,react_experimental_.useRef)(null);
    (0,react_experimental_.useEffect)(()=>{
        const unloadCallback = (event)=>{
            event.preventDefault();
            event.returnValue = "";
            return "";
        };
        if (recipeRef.current && (!isLoaded || !userId)) {
            window.addEventListener("beforeunload", unloadCallback);
        }
        return ()=>window.removeEventListener("beforeunload", unloadCallback);
    });
    const generateRecipe = (0,react_experimental_.useCallback)(async ()=>{
        setLoading(true);
        selection.sort(function(a, b) {
            return a - b;
        });
        const ingredients = selection.map((id)=>ingredientData[id]);
        const rTitle = await (0,actions/* getRecipeTitle */.$4)(ingredients, mealType);
        if (!rTitle) {
            throw new Error("Error generating title");
        }
        setTitle(rTitle);
        console.log(rTitle);
        const rImage = await (0,actions/* getRecipeImage */.eE)(rTitle);
        if (!rImage) {
            throw new Error("Error generating image");
        }
        setImage(rImage);
        const rDesc = await (0,actions/* getRecipeDescription */.md)(rTitle, ingredients, mealType);
        if (!rDesc) {
            throw new Error("Error generating description");
        }
        setDescription(rDesc);
        const rBody = await (0,actions/* getRecipeBody */.j4)(rTitle, rDesc, ingredients, mealType);
        if (!rBody) {
            throw new Error("Error generating body");
        }
        setBody(rBody);
        let token = undefined;
        if (isLoaded && userId) {
            const tkn = await getToken({
                template: "supabase"
            });
            token = tkn ? tkn : undefined;
        }
        // save to db
        const newRecipe = await (0,supabaseRequests/* addRecipe */.XD)({
            ingredients: String(ingredients),
            title: rTitle,
            description: rDesc,
            recipeBody: rBody,
            token: token,
            mealType: mealType
        });
        if (newRecipe) {
            await (0,supabaseRequests/* saveImageToStorage */.B5)({
                recipeId: newRecipe.id,
                imageUrl: rImage
            });
            await (0,supabaseRequests/* updateRecipeImage */.IU)({
                recipeId: newRecipe.id,
                token: token
            });
            console.log("Saved recipe to db");
            recipeRef.current = newRecipe.id;
        }
        setLoading(false);
    }, [
        getToken,
        isLoaded,
        mealType,
        selection,
        userId
    ]);
    const regenRecipe = async ()=>{
        setLoading(true);
        setTitle("");
        setBody(null);
        setImage("");
        (0,actions/* flushCache */.RB)();
        await generateRecipe();
        setLoading(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: formView ? /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
            initial: false,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex min-h-[calc(100vh-4.1rem)] flex-col items-center justify-center gap-8 py-16 md:flex-row md:py-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                        layout: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* Card */.Zb, {
                            className: "w-80 md:w-72 lg:w-96",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardHeader */.Ol, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                                                    children: "Choose ingredients"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardDescription */.SZ, {
                                                    children: "What will you cook next?"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                            className: `gradient-button text-stone-800 transition-opacity ease-in-out md:hidden ${selection.length > 0 ? "opacity-100" : "opacity-0"}`,
                                            onClick: (e)=>{
                                                setRecipeView(true);
                                                setFormView(false);
                                                e.preventDefault();
                                                generateRecipe();
                                            },
                                            children: "Generate!"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "grid grid-cols-3 gap-4 text-sm text-stone-600 dark:text-stone-500",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(MealTypeButton, {
                                                    mealType: "breakfast",
                                                    mealTypeState: mealType,
                                                    setMealType: setMealType
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(MealTypeButton, {
                                                    mealType: "lunch",
                                                    mealTypeState: mealType,
                                                    setMealType: setMealType
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(MealTypeButton, {
                                                    mealType: "dinner",
                                                    mealTypeState: mealType,
                                                    setMealType: setMealType
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                            type: "search",
                                            placeholder: "Search...",
                                            value: searchQuery,
                                            onChange: (e)=>setSearchQuery(e.target.value),
                                            ref: searchBoxRef
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "h-40 space-y-2 overflow-y-auto pl-1",
                                            children: results.length > 0 && results.map((result)=>/*#__PURE__*/ jsx_runtime_.jsx(AnimatedIngredientItem, {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex items-center space-x-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Checkbox, {
                                                                className: "transition",
                                                                id: result.name,
                                                                checked: selection.includes(result.UsdaId),
                                                                onCheckedChange: (checked)=>{
                                                                    checked ? setSelection([
                                                                        ...selection,
                                                                        result.UsdaId
                                                                    ]) : setSelection(selection.filter((val)=>val !== result.UsdaId));
                                                                    searchBoxRef?.current?.focus();
                                                                    searchBoxRef?.current?.select();
                                                                }
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(label.Label, {
                                                                htmlFor: result.name,
                                                                className: "text-sm lowercase",
                                                                children: result.name
                                                            })
                                                        ]
                                                    })
                                                }, "f" + result.UsdaId))
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col-reverse gap-2 md:grid md:grid-flow-col md:grid-rows-4",
                                children: selection.length > 0 && selection.slice(0, 12).map((ingredientId)=>/*#__PURE__*/ jsx_runtime_.jsx(AnimatedIngredientItem, {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex h-full w-44 items-center gap-4 rounded-xl border px-4 py-2 transition md:w-32 lg:w-44",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react.X, {
                                                    className: "shrink-0 cursor-pointer rounded-xl border p-1 hover:bg-gray-300",
                                                    onClick: ()=>setSelection(selection.filter((val)=>val !== ingredientId))
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(label.Label, {
                                                    className: "text-sm lowercase md:text-xs lg:text-sm",
                                                    children: ingredientData[ingredientId]
                                                })
                                            ]
                                        })
                                    }, ingredientId))
                            }),
                            selection.length > 12 && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mt-4",
                                children: "& more"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        className: `gradient-button absolute bottom-1 right-1 hidden h-12 w-40 text-stone-800 transition-opacity ease-in-out md:bottom-14 md:right-40 md:block ${selection.length > 0 ? "opacity-100" : "opacity-0"}`,
                        onClick: (e)=>{
                            setRecipeView(true);
                            setFormView(false);
                            e.preventDefault();
                            generateRecipe();
                        },
                        children: "Generate"
                    })
                ]
            })
        }) : // recipeView
        /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center",
            children: recipeView && /*#__PURE__*/ jsx_runtime_.jsx(RecipeSheet/* default */.Z, {
                title: title,
                description: description,
                body: body,
                image: image,
                regen: regenRecipe,
                loading: loading,
                recipeId: recipeRef.current,
                initialBookmark: false,
                mealType: mealType
            })
        })
    });
}



/***/ }),

/***/ 76762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RecipeMenubar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 54 modules
var esm = __webpack_require__(3271);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
;// CONCATENATED MODULE: ./public/whatsapp.svg
/* harmony default export */ const whatsapp = ({"src":"/_next/static/media/whatsapp.b60c43dc.svg","height":22,"width":22,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/react-share/lib/index.js
var lib = __webpack_require__(7755);
// EXTERNAL MODULE: ./node_modules/react-to-print/lib/index.js
var react_to_print_lib = __webpack_require__(47285);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-menubar/dist/index.mjs
var dist = __webpack_require__(68055);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
;// CONCATENATED MODULE: ./components/ui/menubar.tsx
/* __next_internal_client_entry_do_not_use__ Menubar,MenubarMenu,MenubarTrigger,MenubarContent,MenubarItem,MenubarSeparator,MenubarLabel,MenubarCheckboxItem,MenubarRadioGroup,MenubarRadioItem,MenubarPortal,MenubarSubContent,MenubarSubTrigger,MenubarGroup,MenubarSub,MenubarShortcut auto */ 




const MenubarMenu = dist/* Menu */.v2;
const MenubarGroup = dist/* Group */.ZA;
const MenubarPortal = dist/* Portal */.h_;
const MenubarSub = dist/* Sub */.Tr;
const MenubarRadioGroup = dist/* RadioGroup */.Ee;
const Menubar = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Root */.fC, {
        ref: ref,
        className: (0,utils.cn)("flex h-9 items-center space-x-1  bg-white p-1 dark:bg-transparent sm:dark:bg-stone-950", className),
        ...props
    }));
Menubar.displayName = dist/* Root */.fC.displayName;
const MenubarTrigger = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Trigger */.xz, {
        ref: ref,
        className: (0,utils.cn)("flex cursor-pointer select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none transition-colors hover:bg-stone-50 dark:hover:bg-stone-600/90", className),
        ...props
    }));
MenubarTrigger.displayName = dist/* Trigger */.xz.displayName;
const MenubarSubTrigger = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* SubTrigger */.fF, {
        ref: ref,
        className: (0,utils.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[state=open]:bg-stone-100 data-[state=open]:text-stone-900 dark:focus:bg-stone-800 dark:focus:text-stone-50 dark:data-[state=open]:bg-stone-800 dark:data-[state=open]:text-stone-50", inset && "pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* ChevronRightIcon */.XCv, {
                className: "ml-auto h-4 w-4"
            })
        ]
    }));
MenubarSubTrigger.displayName = dist/* SubTrigger */.fF.displayName;
const MenubarSubContent = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* SubContent */.tu, {
        ref: ref,
        className: (0,utils.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-stone-200 bg-white p-1 text-stone-950 shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-stone-800 dark:bg-stone-950 dark:text-stone-50", className),
        ...props
    }));
MenubarSubContent.displayName = dist/* SubContent */.tu.displayName;
const MenubarContent = /*#__PURE__*/ react_experimental_.forwardRef(({ className, align = "start", alignOffset = -4, sideOffset = 8, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.h_, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* Content */.VY, {
            ref: ref,
            align: align,
            alignOffset: alignOffset,
            sideOffset: sideOffset,
            className: (0,utils.cn)("z-50 min-w-[12rem] overflow-hidden rounded-md border border-stone-200 bg-white p-1 text-stone-950 shadow-md data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-stone-800 dark:bg-stone-950 dark:text-stone-50", className),
            ...props
        })
    }));
MenubarContent.displayName = dist/* Content */.VY.displayName;
const MenubarItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Item */.ck, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", inset && "pl-8", className),
        ...props
    }));
MenubarItem.displayName = dist/* Item */.ck.displayName;
const MenubarCheckboxItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, children, checked, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* CheckboxItem */.oC, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CheckIcon */.nQG, {
                        className: "h-4 w-4"
                    })
                })
            }),
            children
        ]
    }));
MenubarCheckboxItem.displayName = dist/* CheckboxItem */.oC.displayName;
const MenubarRadioItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* RadioItem */.Rk, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* DotFilledIcon */.jXb, {
                        className: "h-4 w-4 fill-current"
                    })
                })
            }),
            children
        ]
    }));
MenubarRadioItem.displayName = dist/* RadioItem */.Rk.displayName;
const MenubarLabel = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Label */.__, {
        ref: ref,
        className: (0,utils.cn)("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
        ...props
    }));
MenubarLabel.displayName = dist/* Label */.__.displayName;
const MenubarSeparator = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Separator */.Z0, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 my-1 h-px bg-stone-100 dark:bg-stone-800", className),
        ...props
    }));
MenubarSeparator.displayName = dist/* Separator */.Z0.displayName;
const MenubarShortcut = ({ className, ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: (0,utils.cn)("ml-auto text-xs tracking-widest text-stone-500 dark:text-stone-400", className),
        ...props
    });
};
MenubarShortcut.displayname = "MenubarShortcut";


// EXTERNAL MODULE: ./app/actions.ts
var actions = __webpack_require__(12479);
// EXTERNAL MODULE: ./components/RecipeSheet.tsx + 1 modules
var RecipeSheet = __webpack_require__(42686);
// EXTERNAL MODULE: ./components/ui/CreateAnotherButton.tsx
var CreateAnotherButton = __webpack_require__(24551);
// EXTERNAL MODULE: ./components/ui/toast.tsx
var ui_toast = __webpack_require__(71129);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-tooltip/dist/index.mjs
var react_tooltip_dist = __webpack_require__(79428);
;// CONCATENATED MODULE: ./components/ui/tooltip.tsx
/* __next_internal_client_entry_do_not_use__ Tooltip,TooltipTrigger,TooltipContent,TooltipProvider auto */ 



const TooltipProvider = react_tooltip_dist/* Provider */.zt;
const Tooltip = react_tooltip_dist/* Root */.fC;
const TooltipTrigger = react_tooltip_dist/* Trigger */.xz;
const TooltipContent = /*#__PURE__*/ react_experimental_.forwardRef(({ className, sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_tooltip_dist/* Content */.VY, {
        ref: ref,
        sideOffset: sideOffset,
        className: (0,utils.cn)("z-50 overflow-hidden rounded-md bg-stone-900 px-3 py-1.5 text-xs text-stone-50 animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:bg-stone-50 dark:text-stone-900", className),
        ...props
    }));
TooltipContent.displayName = react_tooltip_dist/* Content */.VY.displayName;


// EXTERNAL MODULE: ./components/ui/use-toast.ts
var use_toast = __webpack_require__(34388);
;// CONCATENATED MODULE: ./components/RecipeMenubar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 















function RecipeMenubar({ recipeId, regen, loading, noRegen, initialBookmark, noReturnButton, title, body, description, image, mealType, bookmarkCount }) {
    const router = (0,navigation.useRouter)();
    const [isBookmark, setBookmark] = (0,react_experimental_.useState)(initialBookmark);
    const { toast } = (0,use_toast/* useToast */.pm)();
    const currentURL = `${"http://localhost:3000"}/recipe/${recipeId}/${title?.replace(/\s+/g, "-").toLowerCase()}`;
    const cardRef = (0,react_experimental_.useRef)(null);
    const handlePrint = (0,react_to_print_lib.useReactToPrint)({
        content: ()=>cardRef.current
    });
    const copyToClipboard = ()=>{
        navigator.clipboard.writeText(currentURL);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Menubar, {
        className: `ml-5 mr-3 mt-6 ${noReturnButton ? "justify-end" : "justify-between"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx(RecipeSheet/* default */.Z, {
                    ref: cardRef,
                    recipeId: recipeId,
                    title: title || "",
                    body: body || null,
                    image: image || "",
                    initialBookmark: false,
                    noMenuBar: true,
                    noReturnButton: true,
                    className: "border-0 shadow-none",
                    mealType: mealType,
                    description: description || ""
                })
            }),
            !noReturnButton && /*#__PURE__*/ jsx_runtime_.jsx(CreateAnotherButton/* CreateAnotherButton */.o, {
                loading: loading
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(MenubarMenu, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TooltipProvider, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Tooltip, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipTrigger, {
                                        asChild: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(MenubarTrigger, {
                                            onClick: handlePrint,
                                            disabled: loading,
                                            className: `${loading ? "cursor-not-allowed hover:bg-transparent" : "cursor-pointer"}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Printer */.FBw, {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipContent, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Print"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(MenubarMenu, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TooltipProvider, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Tooltip, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipTrigger, {
                                        asChild: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(MenubarTrigger, {
                                            disabled: loading,
                                            className: `${loading ? "cursor-not-allowed hover:bg-transparent" : "cursor-pointer"}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Share */.mBz, {})
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MenubarContent, {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MenubarItem, {
                                                onClick: ()=>{
                                                    copyToClipboard();
                                                    toast({
                                                        description: "Copied to clipboard!"
                                                    });
                                                },
                                                className: "flex w-full items-center justify-between",
                                                children: [
                                                    "Copy",
                                                    /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Link */.rUS, {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(MenubarItem, {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib.FacebookShareButton, {
                                                    className: "flex w-full items-center justify-between",
                                                    title: `I just learned how to cook ${title} thanks to AI!`,
                                                    hashtag: "#Sauteq",
                                                    url: currentURL,
                                                    children: [
                                                        "Facebook",
                                                        /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Facebook */.s1S, {})
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(MenubarItem, {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib.TwitterShareButton, {
                                                    className: "flex w-full items-center justify-between",
                                                    title: `I just learned how to cook ${title} thanks to AI!`,
                                                    hashtags: [
                                                        "Sauteq",
                                                        "AIChef",
                                                        "recipe"
                                                    ],
                                                    url: currentURL,
                                                    via: "Sauteq",
                                                    children: [
                                                        "Twitter",
                                                        /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Twitter */.tLe, {})
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(MenubarItem, {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib.WhatsappShareButton, {
                                                    className: "flex w-full items-center justify-between",
                                                    title: `I just learned how to cook ${title} thanks to AI! Check it out here`,
                                                    url: currentURL,
                                                    children: [
                                                        "WhatsApp",
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: whatsapp,
                                                            alt: "Share on whatsapp"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(MenubarItem, {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib.EmailShareButton, {
                                                    className: "flex w-full items-center justify-between",
                                                    subject: "AI Recipe Discovery",
                                                    body: `I just learned how to cook ${title} thanks to AI! Check it out here`,
                                                    url: currentURL,
                                                    children: [
                                                        "Email",
                                                        /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Mail */.Mh9, {})
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipContent, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Share"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    !noRegen && /*#__PURE__*/ jsx_runtime_.jsx(MenubarMenu, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TooltipProvider, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Tooltip, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipTrigger, {
                                        asChild: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(MenubarTrigger, {
                                            onClick: async ()=>{
                                                if (regen) {
                                                    setBookmark(false);
                                                    await regen();
                                                }
                                            },
                                            className: `${loading ? "animate-spin cursor-not-allowed hover:bg-transparent" : "animate-none cursor-pointer"}`,
                                            disabled: loading,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* RefreshCcw */.SKx, {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipContent, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Regenerate with same ingredients"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(MenubarMenu, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TooltipProvider, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Tooltip, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipTrigger, {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MenubarTrigger, {
                                            onClick: async ()=>{
                                                const res = await (0,actions/* bookmarkRecipe */.Pt)(recipeId, isBookmark);
                                                if (res == -1) {
                                                    toast({
                                                        title: "Uh oh! Something went wrong.",
                                                        description: "You must sign in to save recipes.",
                                                        action: /*#__PURE__*/ jsx_runtime_.jsx(esm/* SignInButton */.$d, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_toast/* ToastAction */.gD, {
                                                                altText: "Sign in",
                                                                children: "Sign in"
                                                            })
                                                        })
                                                    });
                                                    return;
                                                }
                                                setBookmark(!isBookmark);
                                                router.refresh();
                                            },
                                            disabled: loading,
                                            className: `${loading ? "cursor-not-allowed hover:bg-transparent" : "cursor-pointer"}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Bookmark */.rp_, {
                                                    className: `${isBookmark ? "fill-black dark:fill-white" : "fill-transparent"} transition`
                                                }),
                                                bookmarkCount !== undefined && bookmarkCount !== 0 && bookmarkCount
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(TooltipContent, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Favorite recipe"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 42686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_RecipeSheet)
});

// UNUSED EXPORTS: RecipeContentSkeleton

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(70737);
// EXTERNAL MODULE: ./components/ui/separator.tsx
var separator = __webpack_require__(451);
;// CONCATENATED MODULE: ./components/ui/skeleton.tsx


function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("animate-pulse rounded-md bg-stone-900/10 dark:bg-stone-50/10", className),
        ...props
    });
}


// EXTERNAL MODULE: ./app/eat/page.tsx + 6 modules
var page = __webpack_require__(42596);
// EXTERNAL MODULE: ./components/RecipeMenubar.tsx + 3 modules
var RecipeMenubar = __webpack_require__(76762);
// EXTERNAL MODULE: ./components/ui/CreateAnotherButton.tsx
var CreateAnotherButton = __webpack_require__(24551);
;// CONCATENATED MODULE: ./components/RecipeSheet.tsx











const RecipeSheet = /*#__PURE__*/ (0,react_experimental_.forwardRef)(function RecipeSheet({ recipeId, title, description, body, image, mealType, bookmarkCount, regen, loading, initialBookmark, noReturnButton, noRegen, noMenuBar, className }, ref) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* Card */.Zb, {
        ref: ref,
        className: (0,utils.cn)("my-8 w-[400px] place-self-center border-0 shadow-none dark:bg-transparent sm:rounded-xl  sm:border sm:border-stone-200 sm:shadow sm:dark:border-stone-800 sm:dark:bg-stone-950 md:w-[750px]", className),
        children: [
            !noMenuBar && /*#__PURE__*/ jsx_runtime_.jsx(RecipeMenubar["default"], {
                noRegen: noRegen,
                initialBookmark: initialBookmark,
                recipeId: recipeId,
                loading: loading,
                regen: regen,
                noReturnButton: noReturnButton,
                title: title,
                body: body || undefined,
                description: description,
                image: image,
                mealType: mealType,
                bookmarkCount: bookmarkCount
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(card/* CardHeader */.Ol, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "space-y-8 md:flex md:justify-between md:gap-x-4 md:space-y-0",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                                    className: "mb-6",
                                    children: title === "" ? /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                        className: "h-20 w-full md:w-64"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "scroll-m-20 pb-2 text-3xl font-semibold tracking-tight transition-colors first:mt-0",
                                        children: title
                                    })
                                }),
                                !description ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                            className: "h-4 w-full"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                            className: "h-4 w-full"
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeDescription, {
                                    recipeDescription: description
                                }),
                                mealType !== "any" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-4 flex h-full items-center gap-2 text-stone-600 dark:border-stone-800 dark:text-stone-400",
                                    children: [
                                        "Perfect for",
                                        mealType === "breakfast" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* EggFried */.o4d, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Breakfast"
                                                })
                                            ]
                                        }),
                                        mealType === "lunch" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(page.LunchIcon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Lunch"
                                                })
                                            ]
                                        }),
                                        mealType === "dinner" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Drumstick */.jDc, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Dinner"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:shrink-0",
                            children: image === "" ? /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                className: "h-[350px] w-[350px]"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeImage, {
                                img: image || ""
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator.Separator, {
                className: "mb-11 mt-7"
            }),
            !body ? /*#__PURE__*/ jsx_runtime_.jsx(RecipeContentSkeleton, {}) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeContent, {
                body: body
            }),
            !noReturnButton && /*#__PURE__*/ jsx_runtime_.jsx(card/* CardFooter */.eW, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(CreateAnotherButton/* CreateAnotherButton */.o, {
                    loading: loading
                })
            })
        ]
    });
});
function RecipeDescription({ recipeDescription }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(card/* CardDescription */.SZ, {
        children: recipeDescription
    });
}
function RecipeContent({ body }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Prep Time: ",
                            body["prep-time"]
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Cook Time: ",
                            body["cook-time"]
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Serves: ",
                            body["serves"]
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Ingredients"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "my-6 ml-6 list-disc [&>li]:mt-2",
                children: body.ingredients.map((ingredient)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: ingredient
                    }, ingredient))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator.Separator, {
                className: "my-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Directions"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                className: "my-6 ml-6 list-decimal [&>li]:mt-2",
                children: body.directions.map((direction)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: direction
                    }, direction))
            }),
            body.optional.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "scroll-m-20 text-xl font-semibold tracking-tight",
                        children: "Optional"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "my-6 ml-6 list-disc [&>li]:mt-2",
                        children: body.optional.map((optionalStep)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: optionalStep
                            }, optionalStep))
                    })
                ]
            })
        ]
    });
}
function RecipeContentSkeleton() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "mb-4 space-y-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                        className: "h-3 w-2/3 md:w-1/4"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                        className: "h-3 w-2/3 md:w-1/4"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                        className: "h-3 w-2/3 md:w-1/4"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Ingredients"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "my-4 ml-6 list-none [&>li]:mt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 0),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 1),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 2)
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator.Separator, {
                className: "my-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Directions"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "my-4 ml-6 list-none [&>li]:mt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-11/12"
                        })
                    }, 3),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-11/12"
                        })
                    }, 4),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-11/12"
                        })
                    }, 5),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-3 w-11/12"
                        })
                    }, 6)
                ]
            })
        ]
    });
}
function RecipeImage({ img }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
        priority: true,
        src: img,
        width: 350,
        height: 300,
        alt: "Recipe Image",
        className: "rounded-xl shadow"
    });
}
/* harmony default export */ const components_RecipeSheet = (RecipeSheet);


/***/ }),

/***/ 24551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ CreateAnotherButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44368);


const CreateAnotherButton = ({ loading })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
        className: `${loading ? "cursor-not-allowed" : "cursor-pointer"} text-xs sm:text-sm`,
        disabled: loading,
        onClick: ()=>window.location.reload(),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center justify-between gap-2",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "20",
                    height: "20",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "lucide lucide-move-left",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M6 8L2 12L6 16"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M2 12H22"
                        })
                    ]
                }),
                "Create another"
            ]
        })
    });


/***/ }),

/***/ 81396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Label: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(43618);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11914);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12857);
/* __next_internal_client_entry_do_not_use__ Label auto */ 




const labelVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_2__/* .cva */ .j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .f, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)(labelVariants(), className),
        ...props
    }));
Label.displayName = _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_4__/* .Root */ .f.displayName;



/***/ }),

/***/ 451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Separator: () => (/* binding */ Separator)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_separator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22299);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12857);
/* __next_internal_client_entry_do_not_use__ Separator auto */ 



const Separator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_separator__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .f, {
        ref: ref,
        decorative: decorative,
        orientation: orientation,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("shrink-0 bg-stone-200 dark:bg-stone-800", orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]", className),
        ...props
    }));
Separator.displayName = _radix_ui_react_separator__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .f.displayName;



/***/ }),

/***/ 33275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   LunchIcon: () => (/* binding */ e0),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/app/eat/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);
const e0 = proxy["LunchIcon"];


/***/ })

};
;