"use strict";
exports.id = 914;
exports.ids = [914];
exports.modules = {

/***/ 46914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ GalleryItem),
/* harmony export */   Z: () => (/* binding */ PreviewGallery)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14178);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78419);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(85839);
/* harmony import */ var _ui_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20203);






const PreviewRecipes = [
    194,
    211,
    209,
    210
];
const GalleryItem = ({ title, description, imageSrc, noDescription })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_card__WEBPACK_IMPORTED_MODULE_5__/* .Card */ .Zb, {
        className: "h-full transition duration-200 ease-in-out hover:scale-105",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_card__WEBPACK_IMPORTED_MODULE_5__/* .CardHeader */ .Ol, {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.cn)("grid h-full grid-cols-4 items-center justify-center gap-4", noDescription && "flex flex-col justify-between text-center"),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_card__WEBPACK_IMPORTED_MODULE_5__/* .CardTitle */ .ll, {
                    className: "col-span-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "scroll-m-20  pb-2 text-xl font-semibold tracking-tight transition-colors first:mt-0 md:text-2xl",
                        children: title
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-span-2 justify-self-end",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: imageSrc,
                        width: 533,
                        height: 500,
                        alt: "Recipe Image",
                        className: "rounded-xl shadow"
                    })
                }),
                !noDescription && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_card__WEBPACK_IMPORTED_MODULE_5__/* .CardDescription */ .SZ, {
                    className: "col-span-4 text-sm md:text-base",
                    children: description
                })
            ]
        })
    });
async function PreviewGallery() {
    const recipes = await Promise.all(PreviewRecipes.map((id)=>(0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_3__.getRecipe)({
            recipeId: id
        })));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
        children: recipes.map((r)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: `recipe/${r?.id}/${r?.title.replace(/\s+/g, "-").toLowerCase()}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GalleryItem, {
                    title: r?.title || "",
                    description: r?.description || r?.body.description || "",
                    imageSrc: r?.image_url || ""
                }, r?.title)
            }, r?.id))
    });
}


/***/ })

};
;