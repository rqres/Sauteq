"use strict";
(() => {
var exports = {};
exports.id = 582;
exports.ids = [582];
exports.modules = {

/***/ 36254:
/***/ ((module) => {

module.exports = require("aws-crt");

/***/ }),

/***/ 39491:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ 32081:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 57147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 85158:
/***/ ((module) => {

module.exports = require("http2");

/***/ }),

/***/ 95687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 20183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   headerHooks: () => (/* binding */ headerHooks),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_headers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42394);
/* harmony import */ var next_dist_server_node_polyfill_headers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_headers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_modules_app_route_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69692);
/* harmony import */ var next_dist_server_future_route_modules_app_route_module__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Users_rqres_Code_recipe_ai_app_api_openai_body_route_ts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(78242);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_rqres_Code_recipe_ai_app_api_openai_body_route_ts__WEBPACK_IMPORTED_MODULE_2__]);
_Users_rqres_Code_recipe_ai_app_api_openai_body_route_ts__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/api/openai/body/route","pathname":"/api/openai/body","filename":"route","bundlePath":"app/api/openai/body/route"},"resolvedPagePath":"/Users/rqres/Code/recipe-ai/app/api/openai/body/route.ts","nextConfigOutput":"standalone"}
    const routeModule = new (next_dist_server_future_route_modules_app_route_module__WEBPACK_IMPORTED_MODULE_1___default())({
      ...options,
      userland: _Users_rqres_Code_recipe_ai_app_api_openai_body_route_ts__WEBPACK_IMPORTED_MODULE_2__,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/openai/body/route"

    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 78242:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89335);
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31980);
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sst_node_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sst_node_config__WEBPACK_IMPORTED_MODULE_2__]);
sst_node_config__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const configuration = new openai__WEBPACK_IMPORTED_MODULE_1__.Configuration({
    apiKey: sst_node_config__WEBPACK_IMPORTED_MODULE_2__/* .Config */ .D.OPENAI_KEY
});
const openai = new openai__WEBPACK_IMPORTED_MODULE_1__.OpenAIApi(configuration);
const systemPrompt = 'KEEP THIS REPONSE SHORT & CONCISE! You are a talented chef who can come up with exquisite recipes, no matter the ingredients. The user will send you a list of ingredients they have available, the title of their desired recipe, the description of the recipe, along with the type of the desired meal (breakfast, lunch, dinner or any). Your goal is to respond with a recipe they can cook at home, suitable for the desired meal type. Generate a recipe using ONLY the ingredients the user has available right now. Include cook time, prep time, and an outline of the ingredients required (quantities in imperial units) and the steps needed to prepare this meal. You do not HAVE to use all ingredients. If you feel the ingredients mentioned are too constraining, you may add a note stating optional ingredients that the user may incorporate in order to obtain a better result. These optional ingredients must NOT be crucial to the end recipe! Here is the template you should use for answering queries. Your response should be the string of a valid JSON object that can be easily converted with JSON.parse(). Variables (what you need to fill in) are marked by CAPITALS. Notice that "ingredients", "directions" and "optional" take an array of strings. Make sure that "serves" contains a NUMBER! Do not include step numbers before each step in the directions list. PLEASE DO NOT INCLUDE ANY TEXT OTHER THAN THE STRINGIFIED JSON OBJECT AS REQUESTED. Begin template: { "prep-time": "PREP TIME" ,"cook-time": "COOK TIME ","serves": NO-SERVINGS,"ingredients": ["INGREDIENTS...","INGREDIENTS..."],"directions": ["STEP 1...","STEP 2..."],"optional": ["OPTIONAL STEP/INGREDIENT 1...","OPTIONAL STEP/INGREDIENT 2..."]}';
const POST = async (req)=>{
    const { ingredients, title, description, mealType } = await req.json();
    if (!ingredients || !ingredients.length) {
        return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.json("No ingredients provided", {
            status: 400
        });
    }
    const aiTextResult = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [
            {
                role: "system",
                content: systemPrompt
            },
            {
                role: "user",
                content: `Title: ${title}. Description: ${description}. Ingredients: ${String(ingredients)}. Meal Type: ${mealType}`
            }
        ],
        frequency_penalty: 0.5
    });
    const textResponse = aiTextResult.data.choices[0].message?.content?.trim() || "Problem fetching OpenAI data.";
    return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.json(textResponse);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [998,565,560], () => (__webpack_exec__(20183)));
module.exports = __webpack_exports__;

})();