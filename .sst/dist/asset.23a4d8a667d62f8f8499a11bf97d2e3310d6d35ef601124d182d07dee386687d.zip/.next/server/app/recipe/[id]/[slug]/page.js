(() => {
var exports = {};
exports.id = 797;
exports.ids = [797];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 35927:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client.edge");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 85477:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 22390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'recipe',
        {
        children: [
        '[id]',
        {
        children: [
        '[slug]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19225)), "/Users/rqres/Code/recipe-ai/app/recipe/[id]/[slug]/page.tsx"],
          
        }]
      },
        {
          'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 53403)), "/Users/rqres/Code/recipe-ai/app/recipe/[id]/[slug]/loading.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40812)), "/Users/rqres/Code/recipe-ai/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/rqres/Code/recipe-ai/app/recipe/[id]/[slug]/page.tsx"];

    

    const originalPathname = "/recipe/[id]/[slug]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/recipe/[id]/[slug]/page","pathname":"/recipe/[id]/[slug]","bundlePath":"app/recipe/[id]/[slug]/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 35078:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 451));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76762));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42596))

/***/ }),

/***/ 38152:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89708, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52990));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54390));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84102));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64092));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 451));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76762));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42596))

/***/ }),

/***/ 53403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RPageLoading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20203);
/* harmony import */ var _components_ui_separator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32620);
/* harmony import */ var _components_ui_skeleton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50031);
/* harmony import */ var _components_RecipeSheet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4882);





function RPageLoading() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_card__WEBPACK_IMPORTED_MODULE_1__/* .Card */ .Zb, {
            className: "my-8 w-[400px] place-self-center border-0 px-4 shadow-none dark:bg-transparent sm:rounded-xl sm:border sm:border-stone-200 sm:shadow sm:dark:border-stone-800 sm:dark:bg-stone-950 md:w-[750px]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_1__/* .CardHeader */ .Ol, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "space-y-8 md:flex md:justify-between md:gap-x-4 md:space-y-0",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_1__/* .CardTitle */ .ll, {
                                        className: "mb-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_skeleton__WEBPACK_IMPORTED_MODULE_3__/* .Skeleton */ .O, {
                                            className: "h-20 w-full md:w-64"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_skeleton__WEBPACK_IMPORTED_MODULE_3__/* .Skeleton */ .O, {
                                                className: "h-4 w-full"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_skeleton__WEBPACK_IMPORTED_MODULE_3__/* .Skeleton */ .O, {
                                                className: "h-4 w-full"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "md:shrink-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_skeleton__WEBPACK_IMPORTED_MODULE_3__/* .Skeleton */ .O, {
                                    className: "h-[350px] w-[320px]"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_separator__WEBPACK_IMPORTED_MODULE_2__/* .Separator */ .Z, {
                    className: "mb-11 mt-7"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_RecipeSheet__WEBPACK_IMPORTED_MODULE_4__/* .RecipeContentSkeleton */ .m, {})
            ]
        })
    });
}


/***/ }),

/***/ 19225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RPage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(64980);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(78419);
/* harmony import */ var _clerk_nextjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(54205);
/* harmony import */ var _components_RecipeSheet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4882);





async function RPage({ params }) {
    const recipe = await (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__.getRecipe)({
        recipeId: params.id
    });
    if (!recipe) {
        (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.notFound)();
    }
    let bookmark = false;
    const { userId, getToken } = (0,_clerk_nextjs__WEBPACK_IMPORTED_MODULE_4__/* .auth */ .I8)();
    if (userId) {
        const token = await getToken({
            template: "supabase"
        });
        if (token) {
            bookmark = await (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__.getBookmark)({
                recipeId: params.id,
                userId: userId,
                token: token
            }) ? true : false;
        }
    }
    const bookmarkCount = await (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__.getBookmarkCount)({
        recipeId: params.id
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_RecipeSheet__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            noReturnButton: true,
            noRegen: true,
            title: recipe.title,
            body: recipe.body,
            image: recipe.image_url || "",
            recipeId: params.id,
            initialBookmark: bookmark,
            mealType: recipe.meal_type,
            bookmarkCount: bookmarkCount,
            description: recipe.description || recipe.body.description || ""
        })
    });
}


/***/ }),

/***/ 4882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  m: () => (/* binding */ RecipeContentSkeleton),
  Z: () => (/* binding */ components_RecipeSheet)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(39100);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(4094);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(85839);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(20203);
// EXTERNAL MODULE: ./components/ui/separator.tsx
var separator = __webpack_require__(32620);
// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(50031);
// EXTERNAL MODULE: ./app/eat/page.tsx
var page = __webpack_require__(33275);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/RecipeMenubar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/RecipeMenubar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const RecipeMenubar = (__default__);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(24389);
;// CONCATENATED MODULE: ./components/ui/CreateAnotherButton.tsx


const CreateAnotherButton = ({ loading })=>/*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
        className: `${loading ? "cursor-not-allowed" : "cursor-pointer"} text-xs sm:text-sm`,
        disabled: loading,
        onClick: ()=>window.location.reload(),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center justify-between gap-2",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "20",
                    height: "20",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "lucide lucide-move-left",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M6 8L2 12L6 16"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M2 12H22"
                        })
                    ]
                }),
                "Create another"
            ]
        })
    });

;// CONCATENATED MODULE: ./components/RecipeSheet.tsx











const RecipeSheet = /*#__PURE__*/ (0,react_shared_subset.forwardRef)(function RecipeSheet({ recipeId, title, description, body, image, mealType, bookmarkCount, regen, loading, initialBookmark, noReturnButton, noRegen, noMenuBar, className }, ref) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* Card */.Zb, {
        ref: ref,
        className: (0,utils.cn)("my-8 w-[400px] place-self-center border-0 shadow-none dark:bg-transparent sm:rounded-xl  sm:border sm:border-stone-200 sm:shadow sm:dark:border-stone-800 sm:dark:bg-stone-950 md:w-[750px]", className),
        children: [
            !noMenuBar && /*#__PURE__*/ jsx_runtime_.jsx(RecipeMenubar, {
                noRegen: noRegen,
                initialBookmark: initialBookmark,
                recipeId: recipeId,
                loading: loading,
                regen: regen,
                noReturnButton: noReturnButton,
                title: title,
                body: body || undefined,
                description: description,
                image: image,
                mealType: mealType,
                bookmarkCount: bookmarkCount
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(card/* CardHeader */.Ol, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "space-y-8 md:flex md:justify-between md:gap-x-4 md:space-y-0",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                                    className: "mb-6",
                                    children: title === "" ? /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                        className: "h-20 w-full md:w-64"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "scroll-m-20 pb-2 text-3xl font-semibold tracking-tight transition-colors first:mt-0",
                                        children: title
                                    })
                                }),
                                !description ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                            className: "h-4 w-full"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                            className: "h-4 w-full"
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeDescription, {
                                    recipeDescription: description
                                }),
                                mealType !== "any" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-4 flex h-full items-center gap-2 text-stone-600 dark:border-stone-800 dark:text-stone-400",
                                    children: [
                                        "Perfect for",
                                        mealType === "breakfast" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* EggFried */.o4d, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Breakfast"
                                                })
                                            ]
                                        }),
                                        mealType === "lunch" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(page.LunchIcon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Lunch"
                                                })
                                            ]
                                        }),
                                        mealType === "dinner" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Drumstick */.jDc, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Dinner"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:shrink-0",
                            children: image === "" ? /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                className: "h-[350px] w-[350px]"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeImage, {
                                img: image || ""
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator/* Separator */.Z, {
                className: "mb-11 mt-7"
            }),
            !body ? /*#__PURE__*/ jsx_runtime_.jsx(RecipeContentSkeleton, {}) : /*#__PURE__*/ jsx_runtime_.jsx(RecipeContent, {
                body: body
            }),
            !noReturnButton && /*#__PURE__*/ jsx_runtime_.jsx(card/* CardFooter */.eW, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(CreateAnotherButton, {
                    loading: loading
                })
            })
        ]
    });
});
function RecipeDescription({ recipeDescription }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(card/* CardDescription */.SZ, {
        children: recipeDescription
    });
}
function RecipeContent({ body }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Prep Time: ",
                            body["prep-time"]
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Cook Time: ",
                            body["cook-time"]
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: " ",
                        children: [
                            "Serves: ",
                            body["serves"]
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Ingredients"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "my-6 ml-6 list-disc [&>li]:mt-2",
                children: body.ingredients.map((ingredient)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: ingredient
                    }, ingredient))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator/* Separator */.Z, {
                className: "my-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Directions"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                className: "my-6 ml-6 list-decimal [&>li]:mt-2",
                children: body.directions.map((direction)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: direction
                    }, direction))
            }),
            body.optional.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "scroll-m-20 text-xl font-semibold tracking-tight",
                        children: "Optional"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "my-6 ml-6 list-disc [&>li]:mt-2",
                        children: body.optional.map((optionalStep)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: optionalStep
                            }, optionalStep))
                    })
                ]
            })
        ]
    });
}
function RecipeContentSkeleton() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "mb-4 space-y-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                        className: "h-3 w-2/3 md:w-1/4"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                        className: "h-3 w-2/3 md:w-1/4"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                        className: "h-3 w-2/3 md:w-1/4"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Ingredients"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "my-4 ml-6 list-none [&>li]:mt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 0),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 1),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-1/3 md:w-1/5"
                        })
                    }, 2)
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator/* Separator */.Z, {
                className: "my-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "scroll-m-20 text-xl font-semibold tracking-tight",
                children: "Directions"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "my-4 ml-6 list-none [&>li]:mt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-11/12"
                        })
                    }, 3),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-11/12"
                        })
                    }, 4),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-11/12"
                        })
                    }, 5),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                            className: "h-3 w-11/12"
                        })
                    }, 6)
                ]
            })
        ]
    });
}
function RecipeImage({ img }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
        priority: true,
        src: img,
        width: 350,
        height: 300,
        alt: "Recipe Image",
        className: "rounded-xl shadow"
    });
}
/* harmony default export */ const components_RecipeSheet = (RecipeSheet);


/***/ }),

/***/ 32620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/components/ui/separator.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Separator"];


/***/ }),

/***/ 50031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85839);


function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("animate-pulse rounded-md bg-stone-900/10 dark:bg-stone-50/10", className),
        ...props
    });
}



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [998,565,335,207,380,980,369,341,178,618,209,340,350,537,223,203,920,249], () => (__webpack_exec__(22390)));
module.exports = __webpack_exports__;

})();