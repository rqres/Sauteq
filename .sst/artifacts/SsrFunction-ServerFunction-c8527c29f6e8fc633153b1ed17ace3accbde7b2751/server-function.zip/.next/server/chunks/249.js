exports.id = 249;
exports.ids = [249];
exports.modules = {

/***/ 26249:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'6b7ab8fde58da05f8e17ce0103edf91ace5bb47e': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["flushCache"]),
'72e278535c784d2d86c8676117d4deff087f7439': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["bookmarkRecipe"]),
'1187f1719417aab104c8817678a53ffdd86a460f': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeBody"]),
'716388e086e81fd34f0e0d7284023a90afdd6cb4': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeImage"]),
'37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeDescription"]),
'e1003adffaeb8b179666f45a3d8535a96861eef2': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeTitle"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()
  return action.apply(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  '6b7ab8fde58da05f8e17ce0103edf91ace5bb47e': endpoint.bind(null, '6b7ab8fde58da05f8e17ce0103edf91ace5bb47e'),
  '72e278535c784d2d86c8676117d4deff087f7439': endpoint.bind(null, '72e278535c784d2d86c8676117d4deff087f7439'),
  '1187f1719417aab104c8817678a53ffdd86a460f': endpoint.bind(null, '1187f1719417aab104c8817678a53ffdd86a460f'),
  '716388e086e81fd34f0e0d7284023a90afdd6cb4': endpoint.bind(null, '716388e086e81fd34f0e0d7284023a90afdd6cb4'),
  '37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae': endpoint.bind(null, '37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae'),
  'e1003adffaeb8b179666f45a3d8535a96861eef2': endpoint.bind(null, 'e1003adffaeb8b179666f45a3d8535a96861eef2'),
}


/***/ })

};
;