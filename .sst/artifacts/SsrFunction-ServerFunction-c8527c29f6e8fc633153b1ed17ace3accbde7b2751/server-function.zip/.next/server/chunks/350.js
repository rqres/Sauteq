exports.id = 350;
exports.ids = [350];
exports.modules = {

/***/ 30350:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'b4889c17c14bec14966e4bbb069c01d8e86f60fb': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getRecipes"]),
'8bccfef36489053a4d6d1e4ed27f580019f4a214': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getRecipe"]),
'3dee1128b583587177cfe41943d3cb56e8d85f24': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getUserRecipes"]),
'fb580e2d318ec2393a4b52b73ab07196824e3eca': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getUserFavRecipeCount"]),
'f9641296923c6c593521a643d71b4ffb8304ecc8': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getUserFavoriteRecipes"]),
'427ee56288f29bb9558a815cc5af4226caa85ed2': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["addRecipe"]),
'3a9ea48fca5d036d796769b83f490bd22d369792': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["linkRecipeToUser"]),
'9f2e81979254c620afe859750e1571ad9cd7f601': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["toggleBookmark"]),
'14cddf921444db93d3cc1b43b77b13c9ff98ff5f': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getBookmark"]),
'592822d509b55afcfb798c8946867442497e08c6': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getBookmarkCount"]),
'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["addFollower"]),
'59e4dd9d2b17d9d9a61d5a523b047272c987e132': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["removeFollower"]),
'9bb2364c016ad551a5016e84e9f69434a1a881d0': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["checkFollower"]),
'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getFollowerCount"]),
'b8f38d52aa6ca8dc2925f94a91002f14b39212ac': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getFollowingCount"]),
'80b2afd58497d3cec58ed96f05f3990ae84e1823': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getFollowerList"]),
'6dc210fc74f9f36a3892e4a6a060993096666e4a': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["getFollowingList"]),
'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["saveImageToStorage"]),
'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78419)).then(mod => mod["updateRecipeImage"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()
  return action.apply(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  'b4889c17c14bec14966e4bbb069c01d8e86f60fb': endpoint.bind(null, 'b4889c17c14bec14966e4bbb069c01d8e86f60fb'),
  '8bccfef36489053a4d6d1e4ed27f580019f4a214': endpoint.bind(null, '8bccfef36489053a4d6d1e4ed27f580019f4a214'),
  '3dee1128b583587177cfe41943d3cb56e8d85f24': endpoint.bind(null, '3dee1128b583587177cfe41943d3cb56e8d85f24'),
  'fb580e2d318ec2393a4b52b73ab07196824e3eca': endpoint.bind(null, 'fb580e2d318ec2393a4b52b73ab07196824e3eca'),
  'f9641296923c6c593521a643d71b4ffb8304ecc8': endpoint.bind(null, 'f9641296923c6c593521a643d71b4ffb8304ecc8'),
  '427ee56288f29bb9558a815cc5af4226caa85ed2': endpoint.bind(null, '427ee56288f29bb9558a815cc5af4226caa85ed2'),
  '3a9ea48fca5d036d796769b83f490bd22d369792': endpoint.bind(null, '3a9ea48fca5d036d796769b83f490bd22d369792'),
  '9f2e81979254c620afe859750e1571ad9cd7f601': endpoint.bind(null, '9f2e81979254c620afe859750e1571ad9cd7f601'),
  '14cddf921444db93d3cc1b43b77b13c9ff98ff5f': endpoint.bind(null, '14cddf921444db93d3cc1b43b77b13c9ff98ff5f'),
  '592822d509b55afcfb798c8946867442497e08c6': endpoint.bind(null, '592822d509b55afcfb798c8946867442497e08c6'),
  'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab': endpoint.bind(null, 'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab'),
  '59e4dd9d2b17d9d9a61d5a523b047272c987e132': endpoint.bind(null, '59e4dd9d2b17d9d9a61d5a523b047272c987e132'),
  '9bb2364c016ad551a5016e84e9f69434a1a881d0': endpoint.bind(null, '9bb2364c016ad551a5016e84e9f69434a1a881d0'),
  'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0': endpoint.bind(null, 'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0'),
  'b8f38d52aa6ca8dc2925f94a91002f14b39212ac': endpoint.bind(null, 'b8f38d52aa6ca8dc2925f94a91002f14b39212ac'),
  '80b2afd58497d3cec58ed96f05f3990ae84e1823': endpoint.bind(null, '80b2afd58497d3cec58ed96f05f3990ae84e1823'),
  '6dc210fc74f9f36a3892e4a6a060993096666e4a': endpoint.bind(null, '6dc210fc74f9f36a3892e4a6a060993096666e4a'),
  'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9': endpoint.bind(null, 'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9'),
  'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b': endpoint.bind(null, 'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b'),
}


/***/ }),

/***/ 78419:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  addFollower: () => (/* binding */ addFollower),
  addRecipe: () => (/* binding */ addRecipe),
  checkFollower: () => (/* binding */ checkFollower),
  getBookmark: () => (/* binding */ getBookmark),
  getBookmarkCount: () => (/* binding */ getBookmarkCount),
  getFollowerCount: () => (/* binding */ getFollowerCount),
  getFollowerList: () => (/* binding */ getFollowerList),
  getFollowingCount: () => (/* binding */ getFollowingCount),
  getFollowingList: () => (/* binding */ getFollowingList),
  getRecipe: () => (/* binding */ getRecipe),
  getRecipes: () => (/* binding */ getRecipes),
  getUserFavRecipeCount: () => (/* binding */ getUserFavRecipeCount),
  getUserFavoriteRecipes: () => (/* binding */ getUserFavoriteRecipes),
  getUserRecipes: () => (/* binding */ getUserRecipes),
  linkRecipeToUser: () => (/* binding */ linkRecipeToUser),
  removeFollower: () => (/* binding */ removeFollower),
  saveImageToStorage: () => (/* binding */ saveImageToStorage),
  toggleBookmark: () => (/* binding */ toggleBookmark),
  updateRecipeImage: () => (/* binding */ updateRecipeImage)
});

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-proxy.js
var action_proxy = __webpack_require__(44269);
// EXTERNAL MODULE: ./node_modules/@supabase/supabase-js/dist/main/index.js
var main = __webpack_require__(53066);
;// CONCATENATED MODULE: ./utils/supabaseClient.ts

function supabaseClient(supabaseToken) {
    const options = supabaseToken ? {
        global: {
            headers: {
                Authorization: `Bearer ${supabaseToken}`
            }
        },
        auth: {
            persistSession: false
        }
    } : {
        auth: {
            persistSession: false
        }
    };
    const supabase = (0,main.createClient)("https://outggvemqdylkseydkof.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91dGdndmVtcWR5bGtzZXlka29mIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODcwODUzMjgsImV4cCI6MjAwMjY2MTMyOH0.sHDNyOumaJsFdQrMQK05nPeFJfAZsOvwiDqpUF4zgAQ", options);
    return supabase;
}

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js
var action_validate = __webpack_require__(53559);
;// CONCATENATED MODULE: ./utils/supabaseRequests.ts
/* __next_internal_action_entry_do_not_use__ getRecipes,getRecipe,getUserRecipes,getUserFavRecipeCount,getUserFavoriteRecipes,addRecipe,linkRecipeToUser,toggleBookmark,getBookmark,getBookmarkCount,addFollower,removeFollower,checkFollower,getFollowerCount,getFollowingCount,getFollowerList,getFollowingList,saveImageToStorage,updateRecipeImage */ 

async function getRecipes() {
    const supabase = supabaseClient();
    const { data, error } = await supabase.from("recipes").select("title");
    if (error) {
        console.error(error);
        return [];
    }
    return data;
}
async function getRecipe({ recipeId, token }) {
    const supabase = supabaseClient(token);
    const { data, error } = await supabase.from("recipes").select("*").eq("id", recipeId);
    if (error) {
        console.error(error);
        return;
    }
    return data ? data[0] : null;
}
async function getUserRecipes({ userId, token }) {
    const supabase = supabaseClient(token);
    const { data, error } = await supabase.from("recipes").select("*").eq("user_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function getUserFavRecipeCount({ userId }) {
    const supabase = supabaseClient();
    const { count, error } = await supabase.from("bookmarks").select("*", {
        count: "exact",
        head: true
    }).eq("user_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getUserFavoriteRecipes({ userId, token }) {
    const supabase = supabaseClient(token);
    let { data: favRecipes, error } = await supabase.from("bookmarks").select("recipe_id").eq("user_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    let dataPromises = [];
    if (!favRecipes) return [];
    for(let i = favRecipes.length - 1; i >= 0; i--){
        const favRec = favRecipes[i];
        const rec = getRecipe({
            recipeId: favRec.recipe_id
        });
        dataPromises.push(rec);
    }
    const data = Promise.all(dataPromises);
    return data;
}
async function addRecipe({ token, ingredients, title, description, recipeBody, image_url, mealType }) {
    const supabase = supabaseClient(token);
    const { data, error } = await supabase.from("recipes").insert([
        {
            ingredients: ingredients,
            description: description,
            title: title,
            body: recipeBody,
            image_url: image_url,
            meal_type: mealType
        }
    ]).select();
    if (error) {
        console.error(error);
        return;
    }
    return data[0];
}
async function linkRecipeToUser({ recipeId, userId, token }) {
    const supabase = supabaseClient(token);
    const rec = await getRecipe({
        recipeId
    });
    if (rec?.user_id !== userId && rec?.user_id !== "server") {
        throw new Error("Recipe belongs to someone else");
    }
    const { data, error } = await supabase.from("recipes").update({
        user_id: userId
    }).eq("id", recipeId).select();
    if (error) {
        console.error(error);
        return;
    }
    return data[0];
}
async function toggleBookmark({ recipeId, userId, token, toggle }) {
    const supabase = supabaseClient(token);
    if (toggle) {
        const { error } = await supabase.from("bookmarks").insert([
            {
                user_id: userId,
                recipe_id: recipeId
            }
        ]);
        if (error) {
            console.error(error);
        }
    } else {
        const { error } = await supabase.from("bookmarks").delete().eq("recipe_id", recipeId).eq("user_id", userId);
        if (error) {
            console.error(error);
        }
    }
}
async function getBookmark({ recipeId, userId, token }) {
    const supabase = supabaseClient(token);
    let { data, error } = await supabase.from("bookmarks").select("*").eq("recipe_id", recipeId).eq("user_id", userId);
    if (error) {
        console.error(error);
        return false;
    }
    if (!data) return false;
    return data.length > 0 ? true : false;
}
async function getBookmarkCount({ recipeId }) {
    const supabase = supabaseClient();
    const { count, error } = await supabase.from("bookmarks").select("*", {
        count: "exact",
        head: true
    }).eq("recipe_id", recipeId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function addFollower({ followerId, followeeId, token }) {
    const supabase = supabaseClient(token);
    const { error } = await supabase.from("followers").insert({
        follower_id: followerId,
        followee_id: followeeId
    });
    if (error) {
        console.error(error);
        return;
    }
}
async function removeFollower({ followerId, followeeId, token }) {
    const supabase = supabaseClient(token);
    const { error } = await supabase.from("followers").delete().eq("follower_id", followerId).eq("followee_id", followeeId);
    if (error) {
        console.error(error);
        return;
    }
}
async function checkFollower({ followerId, followeeId }) {
    const supabase = supabaseClient();
    let { data, error } = await supabase.from("followers").select("*").eq("follower_id", followerId).eq("followee_id", followeeId);
    if (error) {
        console.error(error);
        return false;
    }
    if (!data) return false;
    return data.length === 1;
}
async function getFollowerCount({ userId }) {
    const supabase = supabaseClient();
    const { count, error } = await supabase.from("followers").select("*", {
        count: "exact",
        head: true
    }).eq("followee_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getFollowingCount({ userId }) {
    const supabase = supabaseClient();
    const { count, error } = await supabase.from("followers").select("*", {
        count: "exact",
        head: true
    }).eq("follower_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getFollowerList({ userId }) {
    const supabase = supabaseClient();
    const { data, error } = await supabase.from("followers").select("follower_id").eq("followee_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function getFollowingList({ userId }) {
    const supabase = supabaseClient();
    const { data, error } = await supabase.from("followers").select("followee_id").eq("follower_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function saveImageToStorage({ recipeId, imageUrl }) {
    // convert DALL-E image to blob
    const blob = await fetch(imageUrl).then((r)=>r.blob());
    const supabase = supabaseClient();
    // save blob to supabase storage
    const { error: storageError } = await supabase.storage.from("recipe-images").upload(recipeId + ".png", blob);
    if (storageError) {
        console.error(storageError);
        return;
    }
}
async function updateRecipeImage({ recipeId, token }) {
    const supabase = supabaseClient(token);
    // link public url to recipe record
    const { data: publicUrlData } = supabase.storage.from("recipe-images").getPublicUrl(recipeId + ".png");
    const { error } = await supabase.from("recipes").update({
        image_url: publicUrlData.publicUrl
    }).eq("id", recipeId);
    if (error) {
        console.error(error);
    }
}

(0,action_validate/* default */.Z)([
    getRecipes,
    getRecipe,
    getUserRecipes,
    getUserFavRecipeCount,
    getUserFavoriteRecipes,
    addRecipe,
    linkRecipeToUser,
    toggleBookmark,
    getBookmark,
    getBookmarkCount,
    addFollower,
    removeFollower,
    checkFollower,
    getFollowerCount,
    getFollowingCount,
    getFollowerList,
    getFollowingList,
    saveImageToStorage,
    updateRecipeImage
]);
(0,action_proxy/* default */.Z)("b4889c17c14bec14966e4bbb069c01d8e86f60fb", null, getRecipes);
(0,action_proxy/* default */.Z)("8bccfef36489053a4d6d1e4ed27f580019f4a214", null, getRecipe);
(0,action_proxy/* default */.Z)("3dee1128b583587177cfe41943d3cb56e8d85f24", null, getUserRecipes);
(0,action_proxy/* default */.Z)("fb580e2d318ec2393a4b52b73ab07196824e3eca", null, getUserFavRecipeCount);
(0,action_proxy/* default */.Z)("f9641296923c6c593521a643d71b4ffb8304ecc8", null, getUserFavoriteRecipes);
(0,action_proxy/* default */.Z)("427ee56288f29bb9558a815cc5af4226caa85ed2", null, addRecipe);
(0,action_proxy/* default */.Z)("3a9ea48fca5d036d796769b83f490bd22d369792", null, linkRecipeToUser);
(0,action_proxy/* default */.Z)("9f2e81979254c620afe859750e1571ad9cd7f601", null, toggleBookmark);
(0,action_proxy/* default */.Z)("14cddf921444db93d3cc1b43b77b13c9ff98ff5f", null, getBookmark);
(0,action_proxy/* default */.Z)("592822d509b55afcfb798c8946867442497e08c6", null, getBookmarkCount);
(0,action_proxy/* default */.Z)("d3bb40d2cb43b42ad1515bac4cff30fbf24484ab", null, addFollower);
(0,action_proxy/* default */.Z)("59e4dd9d2b17d9d9a61d5a523b047272c987e132", null, removeFollower);
(0,action_proxy/* default */.Z)("9bb2364c016ad551a5016e84e9f69434a1a881d0", null, checkFollower);
(0,action_proxy/* default */.Z)("a5f4f1bc2a67d11ce12067a49101b503b65e0bd0", null, getFollowerCount);
(0,action_proxy/* default */.Z)("b8f38d52aa6ca8dc2925f94a91002f14b39212ac", null, getFollowingCount);
(0,action_proxy/* default */.Z)("80b2afd58497d3cec58ed96f05f3990ae84e1823", null, getFollowerList);
(0,action_proxy/* default */.Z)("6dc210fc74f9f36a3892e4a6a060993096666e4a", null, getFollowingList);
(0,action_proxy/* default */.Z)("eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9", null, saveImageToStorage);
(0,action_proxy/* default */.Z)("eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b", null, updateRecipeImage);


/***/ })

};
;