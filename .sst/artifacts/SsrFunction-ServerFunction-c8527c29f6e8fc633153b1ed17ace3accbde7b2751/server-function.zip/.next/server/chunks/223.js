"use strict";
exports.id = 223;
exports.ids = [223];
exports.modules = {

/***/ 12479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $4: () => (/* binding */ getRecipeTitle),
/* harmony export */   Pt: () => (/* binding */ bookmarkRecipe),
/* harmony export */   RB: () => (/* binding */ flushCache),
/* harmony export */   eE: () => (/* binding */ getRecipeImage),
/* harmony export */   j4: () => (/* binding */ getRecipeBody),
/* harmony export */   md: () => (/* binding */ getRecipeDescription)
/* harmony export */ });
/* harmony import */ var next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56937);
/* harmony import */ var next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53009);
/* harmony import */ var private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(61324);



function __build_action__(action, args) {
  return callServer(action.$$id, args)
}

/* __next_internal_action_entry_do_not_use__ flushCache,bookmarkRecipe,getRecipeBody,getRecipeImage,getRecipeDescription,getRecipeTitle */ 

var flushCache = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("6b7ab8fde58da05f8e17ce0103edf91ace5bb47e");
var bookmarkRecipe = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("72e278535c784d2d86c8676117d4deff087f7439");
var getRecipeBody = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("1187f1719417aab104c8817678a53ffdd86a460f");
var getRecipeImage = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("716388e086e81fd34f0e0d7284023a90afdd6cb4");
var getRecipeDescription = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae");
var getRecipeTitle = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("e1003adffaeb8b179666f45a3d8535a96861eef2");



/***/ }),

/***/ 70737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ol: () => (/* binding */ CardHeader),
/* harmony export */   SZ: () => (/* binding */ CardDescription),
/* harmony export */   Zb: () => (/* binding */ Card),
/* harmony export */   aY: () => (/* binding */ CardContent),
/* harmony export */   eW: () => (/* binding */ CardFooter),
/* harmony export */   ll: () => (/* binding */ CardTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12857);



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-xl border border-stone-200 bg-white text-stone-950 shadow dark:border-stone-800 dark:bg-stone-950 dark:text-stone-50", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-stone-500 dark:text-stone-400", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";



/***/ }),

/***/ 94319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bookmarkRecipe: () => (/* binding */ bookmarkRecipe),
/* harmony export */   flushCache: () => (/* binding */ flushCache),
/* harmony export */   getRecipeBody: () => (/* binding */ getRecipeBody),
/* harmony export */   getRecipeDescription: () => (/* binding */ getRecipeDescription),
/* harmony export */   getRecipeImage: () => (/* binding */ getRecipeImage),
/* harmony export */   getRecipeTitle: () => (/* binding */ getRecipeTitle)
/* harmony export */ });
/* harmony import */ var private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18758);
/* harmony import */ var next_cache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(67036);
/* harmony import */ var next_cache__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_cache__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(73544);
/* harmony import */ var _clerk_nextjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20889);
/* harmony import */ var private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(74050);
/* __next_internal_action_entry_do_not_use__ flushCache,bookmarkRecipe,getRecipeBody,getRecipeImage,getRecipeDescription,getRecipeTitle */ 



const flushCache = ()=>{
    (0,next_cache__WEBPACK_IMPORTED_MODULE_1__.revalidatePath)("/eat");
};
const getRecipeBody = async (title, description, ingredients, mealType)=>{
    console.warn("Connecting to GPT body");
    const res = await fetch("https://d10w1g97siypj3.cloudfront.net" + "/api/openai/body", {
        method: "POST",
        headers: {
            Accept: "application.json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: title,
            description: description,
            ingredients: ingredients,
            mealType: mealType
        })
    });
    if (!res.ok) {
        throw new Error("Failed to connect to OpenAI/text " + res.statusText);
    }
    const GPTText = await res.json();
    const parsedRecipe = sanitizeAndParseGPTText(GPTText);
    return parsedRecipe;
};
const getRecipeDescription = async (title, ingredients, mealType)=>{
    console.warn("Connecting to GPT description");
    const res = await fetch("https://d10w1g97siypj3.cloudfront.net" + "/api/openai/description", {
        method: "POST",
        headers: {
            Accept: "application.json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: title,
            ingredients: ingredients,
            mealType: mealType
        })
    });
    if (!res.ok) {
        throw new Error("Failed to connect to OpenAI/desc " + res.statusText);
    }
    const GPTDesc = await res.json();
    return GPTDesc;
};
const getRecipeTitle = async (recipeIngredients, mealType)=>{
    console.warn("Connecting to GPT title...");
    const res = await fetch("https://d10w1g97siypj3.cloudfront.net" + "/api/openai/title", {
        method: "POST",
        headers: {
            Accept: "application.json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            ingredients: recipeIngredients,
            mealType: mealType
        })
    });
    if (!res.ok) {
        throw new Error("Failed to connect to OpenAI/text/recipeTitle " + res.statusText);
    }
    const GPTTitle = await res.json();
    return GPTTitle;
};
const getRecipeImage = async (recipeTitle)=>{
    console.warn("Connecting to GPT image");
    const res = await fetch("https://d10w1g97siypj3.cloudfront.net" + "/api/openai/image", {
        method: "POST",
        headers: {
            Accept: "application.json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: recipeTitle
        })
    });
    if (!res.ok) {
        throw new Error("Failed to connect to OpenAI/image " + res.statusText);
    }
    const recipeImageURL = await res.json();
    return recipeImageURL;
};
function sanitizeAndParseGPTText(recipeContent) {
    const startIndex = recipeContent.indexOf("{");
    // Find the last occurrence of }
    const endIndex = recipeContent.lastIndexOf("}");
    // Check if { and } are found
    if (startIndex === -1 || endIndex === -1) {
        throw new Error("Invalid text response from GPT, no JSON object detected (missing `{`, `}`)");
    }
    // Extract the JSON object
    const sanitizedObject = recipeContent.substring(startIndex, endIndex + 1);
    try {
        // Validate the JSON object
        const jsonObject = JSON.parse(sanitizedObject);
        removeListNumbering(jsonObject.directions);
        return jsonObject;
    } catch (error) {
        console.log("Invalid JSON object:", error);
        throw new Error("Error parsing GPT response");
    }
}
function removeListNumbering(recipeDirections) {
    const isDigit = (char)=>{
        return !isNaN(parseInt(char)) && !isNaN(Number(char));
    };
    if (!isDigit(recipeDirections[0].charAt(0))) return;
    console.log(">> List numbering detected in directions, cleaning up...");
    for(let i = 0; i < recipeDirections.length; i++){
        const direction = recipeDirections[i];
        if (isDigit(direction.charAt(0))) recipeDirections[i] = direction.slice(3);
    }
}
const bookmarkRecipe = async (recipeId, isBookmark)=>{
    const { userId, getToken } = (0,_clerk_nextjs__WEBPACK_IMPORTED_MODULE_3__.auth)();
    flushCache();
    if (!userId) {
        return -1 //no user
        ;
    }
    console.log("Bookmarking recipe: " + recipeId);
    const token = await getToken({
        template: "supabase"
    });
    if (!token) {
        console.error("Unable to fetch token");
        return -1 //no token
        ;
    }
    (0,_utils_supabaseRequests__WEBPACK_IMPORTED_MODULE_2__.toggleBookmark)({
        recipeId: recipeId,
        userId: userId,
        token: token,
        toggle: !isBookmark
    });
};


(0,private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_4__["default"])([
    flushCache,
    bookmarkRecipe,
    getRecipeBody,
    getRecipeImage,
    getRecipeDescription,
    getRecipeTitle
]);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("6b7ab8fde58da05f8e17ce0103edf91ace5bb47e", null, flushCache);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("72e278535c784d2d86c8676117d4deff087f7439", null, bookmarkRecipe);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("1187f1719417aab104c8817678a53ffdd86a460f", null, getRecipeBody);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("716388e086e81fd34f0e0d7284023a90afdd6cb4", null, getRecipeImage);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae", null, getRecipeDescription);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("e1003adffaeb8b179666f45a3d8535a96861eef2", null, getRecipeTitle);


/***/ }),

/***/ 24320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ supabaseClient)
/* harmony export */ });
/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15114);
/* harmony import */ var _supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__);

function supabaseClient(supabaseToken) {
    const options = supabaseToken ? {
        global: {
            headers: {
                Authorization: `Bearer ${supabaseToken}`
            }
        },
        auth: {
            persistSession: false
        }
    } : {
        auth: {
            persistSession: false
        }
    };
    const supabase = (0,_supabase_supabase_js__WEBPACK_IMPORTED_MODULE_0__.createClient)("https://outggvemqdylkseydkof.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91dGdndmVtcWR5bGtzZXlka29mIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODcwODUzMjgsImV4cCI6MjAwMjY2MTMyOH0.sHDNyOumaJsFdQrMQK05nPeFJfAZsOvwiDqpUF4zgAQ", options);
    return supabase;
}


/***/ }),

/***/ 73544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addFollower: () => (/* binding */ addFollower),
/* harmony export */   addRecipe: () => (/* binding */ addRecipe),
/* harmony export */   checkFollower: () => (/* binding */ checkFollower),
/* harmony export */   getBookmark: () => (/* binding */ getBookmark),
/* harmony export */   getBookmarkCount: () => (/* binding */ getBookmarkCount),
/* harmony export */   getFollowerCount: () => (/* binding */ getFollowerCount),
/* harmony export */   getFollowerList: () => (/* binding */ getFollowerList),
/* harmony export */   getFollowingCount: () => (/* binding */ getFollowingCount),
/* harmony export */   getFollowingList: () => (/* binding */ getFollowingList),
/* harmony export */   getRecipe: () => (/* binding */ getRecipe),
/* harmony export */   getRecipes: () => (/* binding */ getRecipes),
/* harmony export */   getUserFavRecipeCount: () => (/* binding */ getUserFavRecipeCount),
/* harmony export */   getUserFavoriteRecipes: () => (/* binding */ getUserFavoriteRecipes),
/* harmony export */   getUserRecipes: () => (/* binding */ getUserRecipes),
/* harmony export */   linkRecipeToUser: () => (/* binding */ linkRecipeToUser),
/* harmony export */   removeFollower: () => (/* binding */ removeFollower),
/* harmony export */   saveImageToStorage: () => (/* binding */ saveImageToStorage),
/* harmony export */   toggleBookmark: () => (/* binding */ toggleBookmark),
/* harmony export */   updateRecipeImage: () => (/* binding */ updateRecipeImage)
/* harmony export */ });
/* harmony import */ var private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18758);
/* harmony import */ var _supabaseClient__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(24320);
/* harmony import */ var private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74050);
/* __next_internal_action_entry_do_not_use__ getRecipes,getRecipe,getUserRecipes,getUserFavRecipeCount,getUserFavoriteRecipes,addRecipe,linkRecipeToUser,toggleBookmark,getBookmark,getBookmarkCount,addFollower,removeFollower,checkFollower,getFollowerCount,getFollowingCount,getFollowerList,getFollowingList,saveImageToStorage,updateRecipeImage */ 

async function getRecipes() {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { data, error } = await supabase.from("recipes").select("title");
    if (error) {
        console.error(error);
        return [];
    }
    return data;
}
async function getRecipe({ recipeId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const { data, error } = await supabase.from("recipes").select("*").eq("id", recipeId);
    if (error) {
        console.error(error);
        return;
    }
    return data ? data[0] : null;
}
async function getUserRecipes({ userId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const { data, error } = await supabase.from("recipes").select("*").eq("user_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function getUserFavRecipeCount({ userId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { count, error } = await supabase.from("bookmarks").select("*", {
        count: "exact",
        head: true
    }).eq("user_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getUserFavoriteRecipes({ userId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    let { data: favRecipes, error } = await supabase.from("bookmarks").select("recipe_id").eq("user_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    let dataPromises = [];
    if (!favRecipes) return [];
    for(let i = favRecipes.length - 1; i >= 0; i--){
        const favRec = favRecipes[i];
        const rec = getRecipe({
            recipeId: favRec.recipe_id
        });
        dataPromises.push(rec);
    }
    const data = Promise.all(dataPromises);
    return data;
}
async function addRecipe({ token, ingredients, title, description, recipeBody, image_url, mealType }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const { data, error } = await supabase.from("recipes").insert([
        {
            ingredients: ingredients,
            description: description,
            title: title,
            body: recipeBody,
            image_url: image_url,
            meal_type: mealType
        }
    ]).select();
    if (error) {
        console.error(error);
        return;
    }
    return data[0];
}
async function linkRecipeToUser({ recipeId, userId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const rec = await getRecipe({
        recipeId
    });
    if (rec?.user_id !== userId && rec?.user_id !== "server") {
        throw new Error("Recipe belongs to someone else");
    }
    const { data, error } = await supabase.from("recipes").update({
        user_id: userId
    }).eq("id", recipeId).select();
    if (error) {
        console.error(error);
        return;
    }
    return data[0];
}
async function toggleBookmark({ recipeId, userId, token, toggle }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    if (toggle) {
        const { error } = await supabase.from("bookmarks").insert([
            {
                user_id: userId,
                recipe_id: recipeId
            }
        ]);
        if (error) {
            console.error(error);
        }
    } else {
        const { error } = await supabase.from("bookmarks").delete().eq("recipe_id", recipeId).eq("user_id", userId);
        if (error) {
            console.error(error);
        }
    }
}
async function getBookmark({ recipeId, userId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    let { data, error } = await supabase.from("bookmarks").select("*").eq("recipe_id", recipeId).eq("user_id", userId);
    if (error) {
        console.error(error);
        return false;
    }
    if (!data) return false;
    return data.length > 0 ? true : false;
}
async function getBookmarkCount({ recipeId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { count, error } = await supabase.from("bookmarks").select("*", {
        count: "exact",
        head: true
    }).eq("recipe_id", recipeId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function addFollower({ followerId, followeeId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const { error } = await supabase.from("followers").insert({
        follower_id: followerId,
        followee_id: followeeId
    });
    if (error) {
        console.error(error);
        return;
    }
}
async function removeFollower({ followerId, followeeId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    const { error } = await supabase.from("followers").delete().eq("follower_id", followerId).eq("followee_id", followeeId);
    if (error) {
        console.error(error);
        return;
    }
}
async function checkFollower({ followerId, followeeId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    let { data, error } = await supabase.from("followers").select("*").eq("follower_id", followerId).eq("followee_id", followeeId);
    if (error) {
        console.error(error);
        return false;
    }
    if (!data) return false;
    return data.length === 1;
}
async function getFollowerCount({ userId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { count, error } = await supabase.from("followers").select("*", {
        count: "exact",
        head: true
    }).eq("followee_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getFollowingCount({ userId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { count, error } = await supabase.from("followers").select("*", {
        count: "exact",
        head: true
    }).eq("follower_id", userId);
    if (error) {
        console.error(error);
        return 0;
    }
    if (count === null) return 0;
    return count;
}
async function getFollowerList({ userId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { data, error } = await supabase.from("followers").select("follower_id").eq("followee_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function getFollowingList({ userId }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    const { data, error } = await supabase.from("followers").select("followee_id").eq("follower_id", userId);
    if (error) {
        console.error(error);
        return;
    }
    return data;
}
async function saveImageToStorage({ recipeId, imageUrl }) {
    // convert DALL-E image to blob
    const blob = await fetch(imageUrl).then((r)=>r.blob());
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])();
    // save blob to supabase storage
    const { error: storageError } = await supabase.storage.from("recipe-images").upload(recipeId + ".png", blob);
    if (storageError) {
        console.error(storageError);
        return;
    }
}
async function updateRecipeImage({ recipeId, token }) {
    const supabase = (0,_supabaseClient__WEBPACK_IMPORTED_MODULE_1__["default"])(token);
    // link public url to recipe record
    const { data: publicUrlData } = supabase.storage.from("recipe-images").getPublicUrl(recipeId + ".png");
    const { error } = await supabase.from("recipes").update({
        image_url: publicUrlData.publicUrl
    }).eq("id", recipeId);
    if (error) {
        console.error(error);
    }
}

(0,private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_2__["default"])([
    getRecipes,
    getRecipe,
    getUserRecipes,
    getUserFavRecipeCount,
    getUserFavoriteRecipes,
    addRecipe,
    linkRecipeToUser,
    toggleBookmark,
    getBookmark,
    getBookmarkCount,
    addFollower,
    removeFollower,
    checkFollower,
    getFollowerCount,
    getFollowingCount,
    getFollowerList,
    getFollowingList,
    saveImageToStorage,
    updateRecipeImage
]);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("b4889c17c14bec14966e4bbb069c01d8e86f60fb", null, getRecipes);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("8bccfef36489053a4d6d1e4ed27f580019f4a214", null, getRecipe);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("3dee1128b583587177cfe41943d3cb56e8d85f24", null, getUserRecipes);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("fb580e2d318ec2393a4b52b73ab07196824e3eca", null, getUserFavRecipeCount);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("f9641296923c6c593521a643d71b4ffb8304ecc8", null, getUserFavoriteRecipes);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("427ee56288f29bb9558a815cc5af4226caa85ed2", null, addRecipe);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("3a9ea48fca5d036d796769b83f490bd22d369792", null, linkRecipeToUser);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("9f2e81979254c620afe859750e1571ad9cd7f601", null, toggleBookmark);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("14cddf921444db93d3cc1b43b77b13c9ff98ff5f", null, getBookmark);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("592822d509b55afcfb798c8946867442497e08c6", null, getBookmarkCount);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("d3bb40d2cb43b42ad1515bac4cff30fbf24484ab", null, addFollower);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("59e4dd9d2b17d9d9a61d5a523b047272c987e132", null, removeFollower);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("9bb2364c016ad551a5016e84e9f69434a1a881d0", null, checkFollower);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("a5f4f1bc2a67d11ce12067a49101b503b65e0bd0", null, getFollowerCount);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("b8f38d52aa6ca8dc2925f94a91002f14b39212ac", null, getFollowingCount);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("80b2afd58497d3cec58ed96f05f3990ae84e1823", null, getFollowerList);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("6dc210fc74f9f36a3892e4a6a060993096666e4a", null, getFollowingList);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9", null, saveImageToStorage);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b", null, updateRecipeImage);


/***/ })

};
;