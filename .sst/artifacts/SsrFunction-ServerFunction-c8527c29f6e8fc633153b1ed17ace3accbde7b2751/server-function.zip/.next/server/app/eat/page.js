(() => {
var exports = {};
exports.id = 702;
exports.ids = [702];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 35927:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client.edge");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 85477:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 25804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'eat',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33275)), "/Users/rqres/Code/recipe-ai/app/eat/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40812)), "/Users/rqres/Code/recipe-ai/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/rqres/Code/recipe-ai/app/eat/page.tsx"];

    

    const originalPathname = "/eat/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/eat/page","pathname":"/eat","bundlePath":"app/eat/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 84772:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'b4889c17c14bec14966e4bbb069c01d8e86f60fb': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getRecipes"]),
'8bccfef36489053a4d6d1e4ed27f580019f4a214': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getRecipe"]),
'3dee1128b583587177cfe41943d3cb56e8d85f24': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getUserRecipes"]),
'fb580e2d318ec2393a4b52b73ab07196824e3eca': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getUserFavRecipeCount"]),
'f9641296923c6c593521a643d71b4ffb8304ecc8': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getUserFavoriteRecipes"]),
'427ee56288f29bb9558a815cc5af4226caa85ed2': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["addRecipe"]),
'3a9ea48fca5d036d796769b83f490bd22d369792': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["linkRecipeToUser"]),
'9f2e81979254c620afe859750e1571ad9cd7f601': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["toggleBookmark"]),
'14cddf921444db93d3cc1b43b77b13c9ff98ff5f': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getBookmark"]),
'592822d509b55afcfb798c8946867442497e08c6': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getBookmarkCount"]),
'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["addFollower"]),
'59e4dd9d2b17d9d9a61d5a523b047272c987e132': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["removeFollower"]),
'9bb2364c016ad551a5016e84e9f69434a1a881d0': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["checkFollower"]),
'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getFollowerCount"]),
'b8f38d52aa6ca8dc2925f94a91002f14b39212ac': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getFollowingCount"]),
'80b2afd58497d3cec58ed96f05f3990ae84e1823': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getFollowerList"]),
'6dc210fc74f9f36a3892e4a6a060993096666e4a': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["getFollowingList"]),
'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["saveImageToStorage"]),
'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73544)).then(mod => mod["updateRecipeImage"]),
'6b7ab8fde58da05f8e17ce0103edf91ace5bb47e': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["flushCache"]),
'72e278535c784d2d86c8676117d4deff087f7439': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["bookmarkRecipe"]),
'1187f1719417aab104c8817678a53ffdd86a460f': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeBody"]),
'716388e086e81fd34f0e0d7284023a90afdd6cb4': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeImage"]),
'37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeDescription"]),
'e1003adffaeb8b179666f45a3d8535a96861eef2': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94319)).then(mod => mod["getRecipeTitle"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()
  return action.apply(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  'b4889c17c14bec14966e4bbb069c01d8e86f60fb': endpoint.bind(null, 'b4889c17c14bec14966e4bbb069c01d8e86f60fb'),
  '8bccfef36489053a4d6d1e4ed27f580019f4a214': endpoint.bind(null, '8bccfef36489053a4d6d1e4ed27f580019f4a214'),
  '3dee1128b583587177cfe41943d3cb56e8d85f24': endpoint.bind(null, '3dee1128b583587177cfe41943d3cb56e8d85f24'),
  'fb580e2d318ec2393a4b52b73ab07196824e3eca': endpoint.bind(null, 'fb580e2d318ec2393a4b52b73ab07196824e3eca'),
  'f9641296923c6c593521a643d71b4ffb8304ecc8': endpoint.bind(null, 'f9641296923c6c593521a643d71b4ffb8304ecc8'),
  '427ee56288f29bb9558a815cc5af4226caa85ed2': endpoint.bind(null, '427ee56288f29bb9558a815cc5af4226caa85ed2'),
  '3a9ea48fca5d036d796769b83f490bd22d369792': endpoint.bind(null, '3a9ea48fca5d036d796769b83f490bd22d369792'),
  '9f2e81979254c620afe859750e1571ad9cd7f601': endpoint.bind(null, '9f2e81979254c620afe859750e1571ad9cd7f601'),
  '14cddf921444db93d3cc1b43b77b13c9ff98ff5f': endpoint.bind(null, '14cddf921444db93d3cc1b43b77b13c9ff98ff5f'),
  '592822d509b55afcfb798c8946867442497e08c6': endpoint.bind(null, '592822d509b55afcfb798c8946867442497e08c6'),
  'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab': endpoint.bind(null, 'd3bb40d2cb43b42ad1515bac4cff30fbf24484ab'),
  '59e4dd9d2b17d9d9a61d5a523b047272c987e132': endpoint.bind(null, '59e4dd9d2b17d9d9a61d5a523b047272c987e132'),
  '9bb2364c016ad551a5016e84e9f69434a1a881d0': endpoint.bind(null, '9bb2364c016ad551a5016e84e9f69434a1a881d0'),
  'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0': endpoint.bind(null, 'a5f4f1bc2a67d11ce12067a49101b503b65e0bd0'),
  'b8f38d52aa6ca8dc2925f94a91002f14b39212ac': endpoint.bind(null, 'b8f38d52aa6ca8dc2925f94a91002f14b39212ac'),
  '80b2afd58497d3cec58ed96f05f3990ae84e1823': endpoint.bind(null, '80b2afd58497d3cec58ed96f05f3990ae84e1823'),
  '6dc210fc74f9f36a3892e4a6a060993096666e4a': endpoint.bind(null, '6dc210fc74f9f36a3892e4a6a060993096666e4a'),
  'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9': endpoint.bind(null, 'eb3c87bf52a41d4c8a9d1dfa205d881987ddb2a9'),
  'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b': endpoint.bind(null, 'eac7c161d79493e6de55c3da8a1e5cd1fe9d8e3b'),
  '6b7ab8fde58da05f8e17ce0103edf91ace5bb47e': endpoint.bind(null, '6b7ab8fde58da05f8e17ce0103edf91ace5bb47e'),
  '72e278535c784d2d86c8676117d4deff087f7439': endpoint.bind(null, '72e278535c784d2d86c8676117d4deff087f7439'),
  '1187f1719417aab104c8817678a53ffdd86a460f': endpoint.bind(null, '1187f1719417aab104c8817678a53ffdd86a460f'),
  '716388e086e81fd34f0e0d7284023a90afdd6cb4': endpoint.bind(null, '716388e086e81fd34f0e0d7284023a90afdd6cb4'),
  '37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae': endpoint.bind(null, '37a796ef8e4dd9773b2ca9d2c9d593d0cde00eae'),
  'e1003adffaeb8b179666f45a3d8535a96861eef2': endpoint.bind(null, 'e1003adffaeb8b179666f45a3d8535a96861eef2'),
}


/***/ }),

/***/ 82854:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42596))

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [998,335,380,369,341,618,209,340,537,223,920], () => (__webpack_exec__(25804)));
module.exports = __webpack_exports__;

})();