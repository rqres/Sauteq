(() => {
var exports = {};
exports.id = 57;
exports.ids = [57];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 35927:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client.edge");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 85477:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 71576:
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 45109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'favorites',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8900)), "/Users/rqres/Code/recipe-ai/app/favorites/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40812)), "/Users/rqres/Code/recipe-ai/app/layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/rqres/Code/recipe-ai/app/favorites/page.tsx"];

    

    const originalPathname = "/favorites/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/favorites/page","pathname":"/favorites","bundlePath":"app/favorites/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 38949:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89708, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52990));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54390));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84102));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64092));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 44232))

/***/ }),

/***/ 44232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FavoriteItem)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-context-menu/dist/index.mjs
var dist = __webpack_require__(64097);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
;// CONCATENATED MODULE: ./components/ui/context-menu.tsx
/* __next_internal_client_entry_do_not_use__ ContextMenu,ContextMenuTrigger,ContextMenuContent,ContextMenuItem,ContextMenuCheckboxItem,ContextMenuRadioItem,ContextMenuLabel,ContextMenuSeparator,ContextMenuShortcut,ContextMenuGroup,ContextMenuPortal,ContextMenuSub,ContextMenuSubContent,ContextMenuSubTrigger,ContextMenuRadioGroup auto */ 




const ContextMenu = dist/* Root */.fC;
const ContextMenuTrigger = dist/* Trigger */.xz;
const ContextMenuGroup = dist/* Group */.ZA;
const ContextMenuPortal = dist/* Portal */.Uv;
const ContextMenuSub = dist/* Sub */.Tr;
const ContextMenuRadioGroup = dist/* RadioGroup */.Ee;
const ContextMenuSubTrigger = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* SubTrigger */.fF, {
        ref: ref,
        className: (0,utils.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[state=open]:bg-stone-100 data-[state=open]:text-stone-900 dark:focus:bg-stone-800 dark:focus:text-stone-50 dark:data-[state=open]:bg-stone-800 dark:data-[state=open]:text-stone-50", inset && "pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* ChevronRightIcon */.XCv, {
                className: "ml-auto h-4 w-4"
            })
        ]
    }));
ContextMenuSubTrigger.displayName = dist/* SubTrigger */.fF.displayName;
const ContextMenuSubContent = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* SubContent */.tu, {
        ref: ref,
        className: (0,utils.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-stone-200 bg-white p-1 text-stone-950 shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-stone-800 dark:bg-stone-950 dark:text-stone-50", className),
        ...props
    }));
ContextMenuSubContent.displayName = dist/* SubContent */.tu.displayName;
const ContextMenuContent = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.Uv, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* Content */.VY, {
            ref: ref,
            className: (0,utils.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-stone-200 bg-white p-1 text-stone-950 shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-stone-800 dark:bg-stone-950 dark:text-stone-50", className),
            ...props
        })
    }));
ContextMenuContent.displayName = dist/* Content */.VY.displayName;
const ContextMenuItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Item */.ck, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", inset && "pl-8", className),
        ...props
    }));
ContextMenuItem.displayName = dist/* Item */.ck.displayName;
const ContextMenuCheckboxItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, children, checked, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* CheckboxItem */.oC, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CheckIcon */.nQG, {
                        className: "h-4 w-4"
                    })
                })
            }),
            children
        ]
    }));
ContextMenuCheckboxItem.displayName = dist/* CheckboxItem */.oC.displayName;
const ContextMenuRadioItem = /*#__PURE__*/ react_experimental_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* RadioItem */.Rk, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-stone-100 focus:text-stone-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-stone-800 dark:focus:text-stone-50", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* DotFilledIcon */.jXb, {
                        className: "h-4 w-4 fill-current"
                    })
                })
            }),
            children
        ]
    }));
ContextMenuRadioItem.displayName = dist/* RadioItem */.Rk.displayName;
const ContextMenuLabel = /*#__PURE__*/ react_experimental_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Label */.__, {
        ref: ref,
        className: (0,utils.cn)("px-2 py-1.5 text-sm font-semibold text-stone-950 dark:text-stone-50", inset && "pl-8", className),
        ...props
    }));
ContextMenuLabel.displayName = dist/* Label */.__.displayName;
const ContextMenuSeparator = /*#__PURE__*/ react_experimental_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Separator */.Z0, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 my-1 h-px bg-stone-200 dark:bg-stone-800", className),
        ...props
    }));
ContextMenuSeparator.displayName = dist/* Separator */.Z0.displayName;
const ContextMenuShortcut = ({ className, ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: (0,utils.cn)("ml-auto text-xs tracking-widest text-stone-500 dark:text-stone-400", className),
        ...props
    });
};
ContextMenuShortcut.displayName = "ContextMenuShortcut";


// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./utils/supabaseRequests.ts
var supabaseRequests = __webpack_require__(76537);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(70737);
;// CONCATENATED MODULE: ./components/PreviewGallery.tsx






const PreviewRecipes = (/* unused pure expression or super */ null && ([
    194,
    211,
    209,
    210
]));
const GalleryItem = ({ title, description, imageSrc, noDescription })=>/*#__PURE__*/ jsx_runtime_.jsx(card/* Card */.Zb, {
        className: "h-full transition duration-200 ease-in-out hover:scale-105",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardHeader */.Ol, {
            className: (0,utils.cn)("grid h-full grid-cols-4 items-center justify-center gap-4", noDescription && "flex flex-col justify-between text-center"),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                    className: "col-span-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "scroll-m-20  pb-2 text-xl font-semibold tracking-tight transition-colors first:mt-0 md:text-2xl",
                        children: title
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-span-2 justify-self-end",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: imageSrc,
                        width: 533,
                        height: 500,
                        alt: "Recipe Image",
                        className: "rounded-xl shadow"
                    })
                }),
                !noDescription && /*#__PURE__*/ jsx_runtime_.jsx(card/* CardDescription */.SZ, {
                    className: "col-span-4 text-sm md:text-base",
                    children: description
                })
            ]
        })
    });
async function PreviewGallery() {
    const recipes = await Promise.all(PreviewRecipes.map((id)=>getRecipe({
            recipeId: id
        })));
    return /*#__PURE__*/ _jsx("div", {
        className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
        children: recipes.map((r)=>/*#__PURE__*/ _jsx(Link, {
                href: `recipe/${r?.id}/${r?.title.replace(/\s+/g, "-").toLowerCase()}`,
                children: /*#__PURE__*/ _jsx(GalleryItem, {
                    title: r?.title || "",
                    description: r?.description || r?.body.description || "",
                    imageSrc: r?.image_url || ""
                }, r?.title)
            }, r?.id))
    });
}

// EXTERNAL MODULE: ./app/actions.ts
var actions = __webpack_require__(12479);
;// CONCATENATED MODULE: ./app/favorites/FavoriteItem.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





function FavoriteItem({ recipe }) {
    const router = (0,navigation.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContextMenu, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuTrigger, {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: `recipe/${recipe?.id}/${recipe?.title.replace(/\s+/g, "-").toLowerCase()}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(GalleryItem, {
                        title: recipe?.title || "",
                        description: recipe?.description || "",
                        imageSrc: recipe?.image_url || "",
                        noDescription: true
                    }, recipe?.title)
                }, recipe?.id)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuContent, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuItem, {
                    onClick: ()=>{
                        (0,actions/* bookmarkRecipe */.Pt)(recipe?.id, true);
                        router.refresh();
                    },
                    children: "Remove from favorites"
                })
            })
        ]
    });
}


/***/ }),

/***/ 8900:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FavoritesPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(64980);
// EXTERNAL MODULE: ./utils/supabaseRequests.ts + 1 modules
var supabaseRequests = __webpack_require__(78419);
// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js + 21 modules
var esm = __webpack_require__(54205);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./app/favorites/FavoriteItem.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/rqres/Code/recipe-ai/app/favorites/FavoriteItem.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const FavoriteItem = (__default__);
;// CONCATENATED MODULE: ./app/favorites/page.tsx





async function FavoritesPage() {
    const { userId, getToken } = (0,esm/* auth */.I8)();
    if (!userId) {
        (0,navigation.notFound)();
    }
    const token = await getToken({
        template: "supabase"
    });
    if (!token) {
        (0,navigation.notFound)();
    }
    const recipes = await (0,supabaseRequests.getUserFavoriteRecipes)({
        userId: userId,
        token: token
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "my-6 scroll-m-20 text-center text-3xl font-extrabold tracking-tight lg:text-5xl",
                children: "Favorites"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "m-auto mb-6 w-72 text-center leading-7 text-stone-600 dark:text-stone-400 md:w-full [&:not(:first-child)]:mt-6",
                children: "Favorite recipes will be publicly displayed on your profile."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid grid-cols-1 gap-4 px-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
                children: recipes?.map((r)=>/*#__PURE__*/ jsx_runtime_.jsx(FavoriteItem, {
                        recipe: r
                    }))
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [998,565,335,207,380,980,369,341,97,340,350,537,223,249], () => (__webpack_exec__(45109)));
module.exports = __webpack_exports__;

})();